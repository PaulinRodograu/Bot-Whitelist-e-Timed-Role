import discord
from config.servidor_config import SERVER_CONFIG
from config.bot_config import EMBED_CONFIGS

class PanelManager:
    def __init__(self, bot):
        self.bot = bot
    
    async def check_and_update_panel(self):
        try:
            channel = self.bot.get_channel(SERVER_CONFIG['PAINEL_CHANNEL_ID'])
            if not channel:
                print(f"❌ Canal do painel não encontrado: {SERVER_CONFIG['PAINEL_CHANNEL_ID']}")
                return
            
            bot_message = None
            async for message in channel.history(limit=50):
                if message.author == self.bot.user and message.embeds:
                    bot_message = message
                    break
            
            if bot_message:
                await self.update_panel_message(bot_message)
            else:
                print("ℹ️ Nenhuma mensagem do painel encontrada. Use cc.enviar-painel para criar uma.")
                
        except Exception as e:
            print(f"❌ Erro ao verificar painel: {e}")
    
    async def send_panel(self):
        try:
            channel = self.bot.get_channel(SERVER_CONFIG['PAINEL_CHANNEL_ID'])
            if not channel:
                raise Exception(f"Canal não encontrado: {SERVER_CONFIG['PAINEL_CHANNEL_ID']}")
            
            bot_message = None
            async for message in channel.history(limit=50):
                if message.author == self.bot.user and message.embeds:
                    bot_message = message
                    break
            
            # IMPORTANTE: Embed personalizado para painel - Mantenha este comentário para personalização
            embed = self.bot.embed_builder.create_panel_embed()
            view = WhitelistPanelView(self.bot)
            
            if bot_message:
                await bot_message.edit(embed=embed, view=view)
            else:
                await channel.send(embed=embed, view=view)
                
        except Exception as e:
            raise Exception(f"Erro ao enviar painel: {e}")
    
    async def update_panel_message(self, message: discord.Message):
        try:
            embed = self.bot.embed_builder.create_panel_embed()
            view = WhitelistPanelView(self.bot)
            await message.edit(embed=embed, view=view)
            
        except Exception as e:
            print(f"❌ Erro ao atualizar painel: {e}")

class WhitelistPanelView(discord.ui.View):
    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot
    
    @discord.ui.button(
        label='Iniciar Whitelist', 
        emoji='📝', 
        style=discord.ButtonStyle.success,
        custom_id='start_whitelist'
    )
    async def start_whitelist(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            user = interaction.user
            
            if self.bot.db_manager.get_whitelist_session(user.id):
                return await interaction.response.send_message(
                    "⚠️ Você já tem uma whitelist em andamento! Complete-a antes de iniciar uma nova.",
                    ephemeral=True
                )
            
            if self.bot.db_manager.is_user_on_cooldown(user.id):
                remaining_time = self.bot.db_manager.get_user_cooldown_remaining(user.id)
                
                if remaining_time:
                    embed = discord.Embed(
                        title="⏰ Cooldown Ativo",
                        description=f"**Você precisa aguardar um pouco antes de fazer outra whitelist!**\n\n"
                                  f"⏳ **Tempo restante:** {remaining_time}\n\n"
                                  f"💡 **Dica:** Use este tempo para refinar sua história e personagem!",
                        color=0xFFA500
                    )
                    embed.set_footer(text="O cooldown existe para manter a qualidade das whitelists")
                    
                    return await interaction.response.send_message(embed=embed, ephemeral=True)
            
            if self.bot.db_manager.get_submitted_form(user.id):
                return await interaction.response.send_message(
                    "⚠️ Você já enviou uma whitelist recentemente. Aguarde a análise!",
                    ephemeral=True
                )
            
            embed = self.bot.embed_builder.create_dm_confirmation_embed()
            view = DMConfirmationView(self.bot, user)
            
            await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
            
        except Exception as e:
            await interaction.response.send_message(f"❌ Erro ao iniciar whitelist: {e}", ephemeral=True)

class DMConfirmationView(discord.ui.View):
    def __init__(self, bot, user):
        super().__init__(timeout=300)
        self.bot = bot
        self.user = user
    
    @discord.ui.button(
        label='Continuar', 
        emoji='✅', 
        style=discord.ButtonStyle.success
    )
    async def continue_whitelist(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user.id:
            return await interaction.response.send_message("❌ Este não é seu botão!", ephemeral=True)
        
        try:
            success = await self.bot.whitelist_handler.start_whitelist(self.user)
            
            if success:
                await interaction.response.send_message(
                    "✅ Whitelist iniciada! Verifique sua DM para responder às perguntas.",
                    ephemeral=True
                )
            else:
                await interaction.response.send_message(
                    "❌ Não foi possível iniciar a whitelist. Verifique se suas DMs estão abertas!",
                    ephemeral=True
                )
                
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(f"❌ Erro: {e}", ephemeral=True)
                else:
                    await interaction.followup.send(f"❌ Erro: {e}", ephemeral=True)
            except:
                # Se ainda assim falhar, apenas log o erro
                print(f"❌ Erro na whitelist para {self.user}: {e}")
    
    @discord.ui.button(
        label='Cancelar', 
        emoji='❌', 
        style=discord.ButtonStyle.danger
    )
    async def cancel_whitelist(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user.id:
            return await interaction.response.send_message("❌ Este não é seu botão!", ephemeral=True)
        
        try:
            await interaction.response.send_message("❌ Whitelist cancelada.", ephemeral=True)
        except Exception as e:
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message("❌ Whitelist cancelada.", ephemeral=True)
                else:
                    await interaction.followup.send("❌ Whitelist cancelada.", ephemeral=True)
            except:
                print(f"❌ Erro ao cancelar whitelist para {self.user}: {e}")

"""
MIT License
Copyright (c) 2026 Paulo Roberto Duarte Freitas
"""
