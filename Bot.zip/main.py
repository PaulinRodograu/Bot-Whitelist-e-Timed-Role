import logging
# Configure logging as early as possible so discord.py INFO logs (gateway/connect)
# are suppressed. Change level to INFO or DEBUG if you want more verbosity.
logging.basicConfig(level=logging.WARNING, format='%(asctime)s %(levelname)8s %(name)s %(message)s')
logging.getLogger('discord').setLevel(logging.WARNING)
logging.getLogger('discord.gateway').setLevel(logging.WARNING)

import discord
from discord.ext import commands, tasks
import asyncio
import json
import os
from datetime import datetime, timedelta
import traceback

from config.bot_config import BOT_CONFIG
from config.servidor_config import SERVER_CONFIG, COMMAND_PERMISSIONS
from config.perguntas_config import PERGUNTAS_CONFIG

from modules.database_manager import DatabaseManager
from modules.embed_builder import EmbedBuilder
from modules.whitelist_handler import WhitelistHandler
from modules.role_manager import RoleManager
from modules.panel_manager import PanelManager
from modules.moderation_manager import ModerationManager

class WhitelistBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        intents.guilds = True
        
        super().__init__(
            command_prefix=BOT_CONFIG['PREFIX'],
            intents=intents,
            help_command=None
        )
        
        self.db_manager = DatabaseManager()
        self.embed_builder = EmbedBuilder()
        self.moderation_manager = ModerationManager(self)
        self.whitelist_handler = WhitelistHandler(self)
        self.role_manager = RoleManager(self)
        self.panel_manager = PanelManager(self)
        
    async def setup_hook(self):
        try:
            self.db_manager.initialize_databases()
            await self.add_persistent_views()
            await self.restore_after_restart()
            
            self.cleanup_databases.start()
            self.check_temporary_roles.start()
            asyncio.create_task(self.moderation_manager.check_temp_roles())
            
            # Sincronização condicional para evitar rate limiting
            await self.sync_commands_safely()
            
            print(f"✅ Bot {self.user} está online!")
            
        except Exception as e:
            print(f"❌ Erro na configuração inicial: {e}")
            traceback.print_exc()
    
    async def sync_commands_safely(self):
        """Sincroniza comandos de forma segura, evitando rate limiting"""
        try:
            # Verifica se já temos comandos registrados
            existing_commands = await self.tree.fetch_commands()
            
            # Se não há comandos ou se estamos em desenvolvimento, sincroniza
            if not existing_commands or BOT_CONFIG.get('FORCE_SYNC', False):
                print("🔄 Sincronizando comandos...")
                synced_commands = await self.tree.sync()
                print(f"✅ {len(synced_commands)} slash commands sincronizados")
            else:
                print(f"✅ {len(existing_commands)} comandos já registrados, pulando sincronização")
                
        except discord.HTTPException as e:
            if e.status == 429:  # Rate limited
                retry_after = e.retry_after if hasattr(e, 'retry_after') else 10
                print(f"⚠️ Rate limited! Aguardando {retry_after} segundos...")
                await asyncio.sleep(retry_after)
                # Tenta novamente uma vez
                try:
                    synced_commands = await self.tree.sync()
                    print(f"✅ {len(synced_commands)} slash commands sincronizados (após rate limit)")
                except Exception as retry_error:
                    print(f"❌ Erro ao sincronizar após rate limit: {retry_error}")
            else:
                print(f"❌ Erro HTTP ao sincronizar comandos: {e}")
        except Exception as e:
            print(f"❌ Erro inesperado ao sincronizar comandos: {e}")
    
    async def on_ready(self):
        try:
            await asyncio.sleep(1)
            
            if BOT_CONFIG['STATUS_TYPE'] == 'playing':
                activity = discord.Game(name=BOT_CONFIG['STATUS_TEXT'])
            elif BOT_CONFIG['STATUS_TYPE'] == 'watching':
                activity = discord.Activity(type=discord.ActivityType.watching, name=BOT_CONFIG['STATUS_TEXT'])
            elif BOT_CONFIG['STATUS_TYPE'] == 'listening':
                activity = discord.Activity(type=discord.ActivityType.listening, name=BOT_CONFIG['STATUS_TEXT'])
            else:
                activity = None
            
            await self.change_presence(
                status=discord.Status.online,
                activity=activity
            )
            
            await self.whitelist_handler.restore_incomplete_sessions()
            await self.panel_manager.check_and_update_panel()
            
        except Exception as e:
            print(f"❌ Erro no evento on_ready: {e}")
    
    async def restore_after_restart(self):
        try:
            print("🔄 Iniciando restauração após restart...")
            
            await asyncio.sleep(3)
            await self.whitelist_handler.restore_whitelist_sessions()
            
            print("🔄 Restaurando botões de formulários...")
            await self.whitelist_handler.restore_form_buttons()
            
            print("✅ Restauração após restart concluída")
            
        except Exception as e:
            print(f"❌ Erro ao restaurar após restart: {e}")
    
    @tasks.loop(hours=24)
    async def cleanup_databases(self):
        try:
            self.db_manager.cleanup_databases()
            print("🧹 Limpeza automática dos bancos de dados realizada")
        except Exception as e:
            print(f"❌ Erro na limpeza automática: {e}")
    
    @tasks.loop(minutes=5)
    async def check_temporary_roles(self):
        try:
            await self.role_manager.check_expired_roles()
        except Exception as e:
            print(f"❌ Erro ao verificar cargos temporários: {e}")
    
    def check_permissions(self, ctx_or_interaction, command_name):
        if hasattr(ctx_or_interaction, 'author'):
            user = ctx_or_interaction.author
            guild = ctx_or_interaction.guild
        else:
            user = ctx_or_interaction.user
            guild = ctx_or_interaction.guild
        
        if not guild:
            # If no guild context, try to get from SERVER_CONFIG
            guild = self.get_guild(SERVER_CONFIG['GUILD_ID'])
            if not guild:
                return False
        
        if user.id == guild.owner_id:
            return True
        
        if command_name not in COMMAND_PERMISSIONS or not COMMAND_PERMISSIONS[command_name]:
            return True
        
        member = guild.get_member(user.id)
        if not member:
            # User is not in the guild, no permissions
            return False
            
        user_role_ids = [role.id for role in member.roles]
        required_roles = COMMAND_PERMISSIONS[command_name]
        
        return any(role_id in user_role_ids for role_id in required_roles)

    async def on_message(self, message):
        if message.author == self.user:
            return
        
        if isinstance(message.channel, discord.DMChannel):
            if await self.whitelist_handler.handle_text_message_warning(message):
                return
            
            if await self.whitelist_handler.handle_file_message(message):
                return
        
        await self.process_commands(message)
    
    async def add_persistent_views(self):
        try:
            print("🔧 Configurando views persistentes...")
            
            cooldowns = self.db_manager.get_all_user_cooldowns()
            
            class PersistentFormResponseView(discord.ui.View):
                def __init__(self, bot):
                    super().__init__(timeout=None)
                    self.bot = bot
                
                @discord.ui.button(label='Responder Usuário', emoji='💬', style=discord.ButtonStyle.secondary, custom_id='respond_user')
                async def respond_button(self, interaction: discord.Interaction, button: discord.ui.Button):
                    try:
                        message_id = interaction.message.id
                        user_id = None
                        
                        cooldowns = self.bot.db_manager.get_all_user_cooldowns()
                        for uid, data in cooldowns.items():
                            if isinstance(data, dict) and data.get('message_id') == message_id:
                                user_id = int(uid)
                                break
                        
                        if not user_id:
                            return await interaction.response.send_message("❌ Usuário não encontrado!", ephemeral=True)
                        
                        if not self.bot.check_permissions(interaction, "cc.whitelist-listar"):
                            return await interaction.response.send_message("❌ Você não tem permissão para usar este botão!", ephemeral=True)
                        
                        from modules.whitelist_handler import ResponseModal
                        modal = ResponseModal(self.bot, user_id)
                        await interaction.response.send_modal(modal)
                        
                    except Exception as e:
                        print(f"❌ Erro no botão persistente: {e}")
                        await interaction.response.send_message("❌ Erro interno!", ephemeral=True)
            
            persistent_view = PersistentFormResponseView(self)
            self.add_view(persistent_view)
            
            print(f"✅ View persistente configurada para {len(cooldowns)} formulários")
            
        except Exception as e:
            print(f"❌ Erro ao configurar views persistentes: {e}")

if __name__ == "__main__":
    bot = WhitelistBot()
    
    @bot.tree.command(name="wl", description="Gerenciar whitelists")
    @discord.app_commands.describe(acao="Ação a ser executada")
    @discord.app_commands.choices(acao=[
        discord.app_commands.Choice(name="Listar Ativas", value="listar"),
        discord.app_commands.Choice(name="Enviar Painel", value="painel")
    ])
    async def wl_command(interaction: discord.Interaction, acao: str):
        if not bot.check_permissions(interaction, "wl"):
            return await interaction.response.send_message("❌ Você não tem permissão para usar este comando!", ephemeral=True)
        
        try:
            if acao == "listar":
                await bot.whitelist_handler.list_active_whitelists(interaction)
            elif acao == "painel":
                await bot.panel_manager.send_panel()
                await interaction.response.send_message("✅ Painel enviado com sucesso!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Erro: {e}", ephemeral=True)
    
    @bot.tree.command(name="role-add", description="Adicionar cargo a um usuário")
    @discord.app_commands.describe(usuario="Usuário para receber o cargo", cargo="Cargo a ser adicionado")
    async def role_add_command(interaction: discord.Interaction, usuario: discord.Member, cargo: discord.Role):
        if not bot.check_permissions(interaction, "role-add"):
            return await interaction.response.send_message("❌ Você não tem permissão para usar este comando!", ephemeral=True)
        
        try:
            await bot.role_manager.add_role(interaction, usuario, cargo)
        except Exception as e:
            await interaction.response.send_message(f"❌ Erro ao adicionar cargo: {e}", ephemeral=True)
    
    @bot.tree.command(name="role-remove", description="Remover cargo de um usuário")
    @discord.app_commands.describe(usuario="Usuário para remover o cargo", cargo="Cargo a ser removido")
    async def role_remove_command(interaction: discord.Interaction, usuario: discord.Member, cargo: discord.Role):
        if not bot.check_permissions(interaction, "role-remove"):
            return await interaction.response.send_message("❌ Você não tem permissão para usar este comando!", ephemeral=True)
        
        try:
            await bot.role_manager.remove_role(interaction, usuario, cargo)
        except Exception as e:
            await interaction.response.send_message(f"❌ Erro ao remover cargo: {e}", ephemeral=True)
    
    @bot.tree.command(name="role-temp", description="Adicionar cargo temporário")
    @discord.app_commands.describe(
        usuario="Usuário para receber o cargo",
        cargo="Cargo a ser adicionado",
        tempo="Tempo para o cargo temporário"
    )
    @discord.app_commands.choices(tempo=[
        discord.app_commands.Choice(name="5 minutos", value=5),
        discord.app_commands.Choice(name="10 minutos", value=10),
        discord.app_commands.Choice(name="20 minutos", value=20),
        discord.app_commands.Choice(name="30 minutos", value=30),
        discord.app_commands.Choice(name="1 hora", value=60),
        discord.app_commands.Choice(name="2 horas", value=120),
        discord.app_commands.Choice(name="3 horas", value=180),
        discord.app_commands.Choice(name="10 dias", value=14400),  # 10 * 24 * 60 = 14400 minutes
        discord.app_commands.Choice(name="20 dias", value=28800),  # 20 * 24 * 60 = 28800 minutes  
        discord.app_commands.Choice(name="30 dias", value=43200)   # 30 * 24 * 60 = 43200 minutes
    ])
    async def role_temp_command(interaction: discord.Interaction, usuario: discord.Member, cargo: discord.Role, tempo: int):
        if not bot.check_permissions(interaction, "role-temp"):
            return await interaction.response.send_message("❌ Você não tem permissão para usar este comando!", ephemeral=True)
        
        try:
            await bot.role_manager.add_temporary_role_minutes(interaction, usuario, cargo, tempo)
        except Exception as e:
            await interaction.response.send_message(f"❌ Erro ao adicionar cargo temporário: {e}", ephemeral=True)
    
    @bot.tree.command(name="role-list", description="Listar cargos de um usuário")
    @discord.app_commands.describe(usuario="Usuário para listar os cargos")
    async def role_list_command(interaction: discord.Interaction, usuario: discord.Member):
        if not bot.check_permissions(interaction, "role-list"):
            return await interaction.response.send_message("❌ Você não tem permissão para usar este comando!", ephemeral=True)
        
        try:
            await bot.role_manager.list_user_roles(interaction, usuario)
        except Exception as e:
            await interaction.response.send_message(f"❌ Erro ao listar cargos: {e}", ephemeral=True)
    
    @bot.tree.command(name="reset-cooldown", description="Remover todos os cooldowns e dados de um usuário")
    @discord.app_commands.describe(usuario="Usuário para resetar os cooldowns")
    async def reset_cooldown_command(interaction: discord.Interaction, usuario: discord.Member):
        if not bot.check_permissions(interaction, "reset-cooldown"):
            return await interaction.response.send_message("❌ Você não tem permissão para usar este comando!", ephemeral=True)
        
        try:
            # Remove all user data
            results = bot.db_manager.remove_all_user_data(usuario.id)
            
            # Build response message
            removed_items = []
            if results['cooldowns']:
                removed_items.append("✅ Cooldowns de formulário")
            if results['sessions']:
                removed_items.append("✅ Sessões de whitelist ativas")
            if results['temp_roles']:
                removed_items.append("✅ Cargos temporários")
            if results['moderation_data']:
                removed_items.append("✅ Dados de moderação pendentes")
            
            if removed_items:
                embed = discord.Embed(
                    title="🔄 Cooldown Resetado",
                    description=f"Todos os dados do usuário {usuario.mention} foram removidos:",
                    color=0x00ff00
                )
                embed.add_field(
                    name="Itens Removidos:",
                    value="\n".join(removed_items),
                    inline=False
                )
                embed.add_field(
                    name="Resultado:",
                    value="O usuário pode agora fazer um novo formulário de whitelist imediatamente.",
                    inline=False
                )
                embed.set_footer(text=f"Executado por {interaction.user.display_name}")
            else:
                embed = discord.Embed(
                    title="ℹ️ Nenhum Dado Encontrado",
                    description=f"O usuário {usuario.mention} não possui cooldowns ou dados para remover.",
                    color=0xffaa00
                )
            
            await interaction.response.send_message(embed=embed, ephemeral=True)
            
        except Exception as e:
            await interaction.response.send_message(f"❌ Erro ao resetar cooldown: {e}", ephemeral=True)
    
    @bot.command(name='help')
    async def help_command(ctx):
        if not bot.check_permissions(ctx, "cc.help"):
            return await ctx.send("❌ Você não tem permissão para usar este comando!")
        
        embed = bot.embed_builder.create_help_embed()
        await ctx.send(embed=embed)
    
    @bot.command(name='ping')
    async def ping(ctx):
        if not bot.check_permissions(ctx, "cc.ping"):
            return await ctx.send("❌ Você não tem permissão para usar este comando!")
        
        latency = round(bot.latency * 1000)
        embed = discord.Embed(
            title="🏓 Pong!",
            description=f"Latência: **{latency}ms**",
            color=0x00ff00
        )
        await ctx.send(embed=embed)
    
    @bot.command(name='sync')
    async def sync_commands(ctx):
        """Sincroniza comandos slash manualmente (apenas para administradores)"""
        if not bot.check_permissions(ctx, "cc.sync"):
            return await ctx.send("❌ Você não tem permissão para usar este comando!")
        
        try:
            await ctx.send("🔄 Sincronizando comandos...")
            await bot.sync_commands_safely()
            await ctx.send("✅ Comandos sincronizados com sucesso!")
        except Exception as e:
            await ctx.send(f"❌ Erro ao sincronizar comandos: {e}")
    
    @bot.command(name='test-whitelist')
    async def test_whitelist(ctx):
        """Testa o sistema de whitelist (apenas para administradores)"""
        if not bot.check_permissions(ctx, "cc.test"):
            return await ctx.send("❌ Você não tem permissão para usar este comando!")
        
        try:
            # Testa se os canais estão configurados
            guild = bot.get_guild(SERVER_CONFIG['GUILD_ID'])
            if not guild:
                return await ctx.send(f"❌ Guild não encontrada: {SERVER_CONFIG['GUILD_ID']}")
            
            normal_channel = guild.get_channel(SERVER_CONFIG['FORMULARIOS_CHANNEL_ID'])
            vip_channel = guild.get_channel(SERVER_CONFIG['FORMULARIOS_VIP_CHANNEL_ID'])
            
            embed = discord.Embed(
                title="🧪 Teste de Configuração",
                description="Verificando configurações do sistema de whitelist:",
                color=0x00ff00
            )
            
            embed.add_field(
                name="🏠 Guild",
                value=f"✅ {guild.name} (ID: {guild.id})",
                inline=False
            )
            
            embed.add_field(
                name="📝 Canal Normal",
                value=f"✅ {normal_channel.name} (ID: {normal_channel.id})" if normal_channel else f"❌ Canal não encontrado (ID: {SERVER_CONFIG['FORMULARIOS_CHANNEL_ID']})",
                inline=False
            )
            
            embed.add_field(
                name="⭐ Canal VIP",
                value=f"✅ {vip_channel.name} (ID: {vip_channel.id})" if vip_channel else f"❌ Canal não encontrado (ID: {SERVER_CONFIG['FORMULARIOS_VIP_CHANNEL_ID']})",
                inline=False
            )
            
            # Testa o embed builder
            test_answers = {
                "Teste 1": "Resposta de teste 1",
                "Teste 2": "Resposta de teste 2"
            }
            
            try:
                test_embed = bot.embed_builder.create_form_embed(ctx.author, test_answers)
                embed.add_field(
                    name="🎨 Embed Builder",
                    value="✅ Funcionando corretamente",
                    inline=False
                )
            except Exception as e:
                embed.add_field(
                    name="🎨 Embed Builder",
                    value=f"❌ Erro: {e}",
                    inline=False
                )
            
            await ctx.send(embed=embed)
            
        except Exception as e:
            await ctx.send(f"❌ Erro no teste: {e}")
    
    @bot.command(name='status-whitelist')
    async def status_whitelist(ctx):
        """Mostra o status de todas as whitelists (apenas para administradores)"""
        if not bot.check_permissions(ctx, "cc.status"):
            return await ctx.send("❌ Você não tem permissão para usar este comando!")
        
        try:
            mod_data = bot.db_manager.get_all_moderation_data()
            
            if not mod_data:
                return await ctx.send("📭 Nenhuma whitelist encontrada no sistema.")
            
            # Contar status
            status_count = {}
            for message_id, data in mod_data.items():
                status = data.get('status', 'unknown')
                status_count[status] = status_count.get(status, 0) + 1
            
            embed = discord.Embed(
                title="📊 Status das Whitelists",
                description=f"Total de whitelists: **{len(mod_data)}**",
                color=0x0099ff
            )
            
            # Mostrar contadores de status
            for status, count in status_count.items():
                emoji = {
                    'pending': '🟡',
                    'approved': '✅',
                    'denied': '❌',
                    'unknown': '❓'
                }.get(status, '❓')
                
                embed.add_field(
                    name=f"{emoji} {status.title()}",
                    value=f"**{count}** whitelists",
                    inline=True
                )
            
            # Mostrar últimas 5 whitelists
            recent_whitelists = list(mod_data.items())[-5:]
            if recent_whitelists:
                recent_text = []
                for message_id, data in recent_whitelists:
                    user_id = data.get('user_id', 'Unknown')
                    status = data.get('status', 'unknown')
                    timestamp = data.get('timestamp', 'Unknown')
                    
                    emoji = {
                        'pending': '🟡',
                        'approved': '✅',
                        'denied': '❌',
                        'unknown': '❓'
                    }.get(status, '❓')
                    
                    recent_text.append(f"{emoji} <@{user_id}> - {status} ({timestamp[:10]})")
                
                embed.add_field(
                    name="📋 Últimas 5 Whitelists",
                    value="\n".join(recent_text),
                    inline=False
                )
            
            embed.set_footer(text="Use cc.status-whitelist para atualizar")
            await ctx.send(embed=embed)
            
        except Exception as e:
            await ctx.send(f"❌ Erro ao verificar status: {e}")

try:
    bot.run(BOT_CONFIG['TOKEN'])
except Exception as e:
    print(f"❌ Erro ao executar o bot: {e}")
    traceback.print_exc()

"""
MIT License
Copyright (c) 2026 Paulo Roberto Duarte Freitas
"""
