import discord
from discord.ext import commands
import re
from datetime import datetime, timedelta
from typing import Optional

from config.servidor_config import SERVER_CONFIG

class RoleManager:
    def __init__(self, bot):
        self.bot = bot
    
    async def add_role(self, ctx_or_interaction, user: discord.Member, role: discord.Role):
        try:
            if not self.can_manage_role(role):
                return await self._send_response(ctx_or_interaction, "❌ Este cargo não pode ser gerenciado pelo bot!")
            
            if role in user.roles:
                return await self._send_response(ctx_or_interaction, f"❌ {user.mention} já possui o cargo {role.mention}!")
            
            author = ctx_or_interaction.user if hasattr(ctx_or_interaction, 'user') else ctx_or_interaction.author
            await user.add_roles(role, reason=f"Adicionado por {author}")
            
            embed = discord.Embed(
                title="✅ Cargo Adicionado",
                description=f"Cargo {role.mention} foi adicionado a {user.mention}",
                color=0x00ff00
            )
            embed.set_footer(text=f"Executado por: {author.display_name}")
            
            await self._send_response(ctx_or_interaction, embed=embed)
            
        except discord.Forbidden:
            await self._send_response(ctx_or_interaction, "❌ Não tenho permissão para gerenciar este cargo!")
        except Exception as e:
            await self._send_response(ctx_or_interaction, f"❌ Erro ao adicionar cargo: {e}")
    
    async def remove_role(self, ctx_or_interaction, user: discord.Member, role: discord.Role):
        try:
            if not self.can_manage_role(role):
                return await self._send_response(ctx_or_interaction, "❌ Este cargo não pode ser gerenciado pelo bot!")
            
            if role not in user.roles:
                return await self._send_response(ctx_or_interaction, f"❌ {user.mention} não possui o cargo {role.mention}!")
            
            author = ctx_or_interaction.user if hasattr(ctx_or_interaction, 'user') else ctx_or_interaction.author
            await user.remove_roles(role, reason=f"Removido por {author}")
            
            self.bot.db_manager.remove_temporary_role(user.id, role.id)
            
            embed = discord.Embed(
                title="✅ Cargo Removido",
                description=f"Cargo {role.mention} foi removido de {user.mention}",
                color=0xff0000
            )
            embed.set_footer(text=f"Executado por: {author.display_name}")
            
            await self._send_response(ctx_or_interaction, embed=embed)
            
        except discord.Forbidden:
            await self._send_response(ctx_or_interaction, "❌ Não tenho permissão para gerenciar este cargo!")
        except Exception as e:
            await self._send_response(ctx_or_interaction, f"❌ Erro ao remover cargo: {e}")
    
    async def list_user_roles(self, ctx_or_interaction, user: discord.Member):
        try:
            roles = [role for role in user.roles if role.name != "@everyone"]
            
            embed = self.bot.embed_builder.create_role_list_embed(user, roles)
            await self._send_response(ctx_or_interaction, embed=embed)
            
        except Exception as e:
            await self._send_response(ctx_or_interaction, f"❌ Erro ao listar cargos: {e}")
    
    async def add_temporary_role(self, ctx_or_interaction, user: discord.Member, role: discord.Role, time_str: str):
        try:
            if not self.can_manage_role(role):
                return await self._send_response(ctx_or_interaction, "❌ Este cargo não pode ser gerenciado pelo bot!")
            
            duration = self.parse_time_duration(time_str)
            if not duration:
                return await self._send_response(ctx_or_interaction, "❌ Formato de tempo inválido! Use: 1h, 1d, 1w, etc.")
            
            if role in user.roles:
                return await self._send_response(ctx_or_interaction, f"❌ {user.mention} já possui o cargo {role.mention}!")
            
            author = ctx_or_interaction.user if hasattr(ctx_or_interaction, 'user') else ctx_or_interaction.author
            await user.add_roles(role, reason=f"Cargo temporário adicionado por {author}")
            
            expires_at = datetime.now() + duration
            self.bot.db_manager.add_temporary_role(user.id, role.id, expires_at)
            
            embed = discord.Embed(
                title="⏰ Cargo Temporário Adicionado",
                description=f"Cargo {role.mention} foi adicionado a {user.mention}",
                color=0xffa500
            )
            embed.add_field(name="⏱️ Duração:", value=time_str, inline=True)
            embed.add_field(name="📅 Expira em:", value=f"<t:{int(expires_at.timestamp())}:R>", inline=True)
            embed.set_footer(text=f"Executado por: {author.display_name}")
            
            await self._send_response(ctx_or_interaction, embed=embed)
            
        except discord.Forbidden:
            await self._send_response(ctx_or_interaction, "❌ Não tenho permissão para gerenciar este cargo!")
        except Exception as e:
            await self._send_response(ctx_or_interaction, f"❌ Erro ao adicionar cargo temporário: {e}")
    
    async def add_temporary_role_minutes(self, ctx_or_interaction, user: discord.Member, role: discord.Role, minutes: int):
        try:
            if not self.can_manage_role(role):
                return await self._send_response(ctx_or_interaction, "❌ Este cargo não pode ser gerenciado pelo bot!")
            
            if minutes <= 0 or minutes > 50000:  # Max limit
                return await self._send_response(ctx_or_interaction, "❌ Tempo deve ser entre 1 e 50000 minutos!")
            
            if role in user.roles:
                return await self._send_response(ctx_or_interaction, f"❌ {user.mention} já possui o cargo {role.mention}!")
            
            author = ctx_or_interaction.user if hasattr(ctx_or_interaction, 'user') else ctx_or_interaction.author
            await user.add_roles(role, reason=f"Cargo temporário adicionado por {author}")
            
            expires_at = datetime.now() + timedelta(minutes=minutes)
            
            self.bot.db_manager.add_temporary_role(user.id, role.id, expires_at)
            
            if minutes < 60:
                time_display = f"{minutes} minutos"
            elif minutes < 1440:  # Less than 24 hours
                hours = minutes // 60
                remaining_minutes = minutes % 60
                if remaining_minutes == 0:
                    time_display = f"{hours} hora{'s' if hours > 1 else ''}"
                else:
                    time_display = f"{hours}h {remaining_minutes}min"
            else:  # Days
                days = minutes // 1440
                remaining_hours = (minutes % 1440) // 60
                if remaining_hours == 0:
                    time_display = f"{days} dia{'s' if days > 1 else ''}"
                else:
                    time_display = f"{days}d {remaining_hours}h"
            
            embed = discord.Embed(
                title="⏰ Cargo Temporário Adicionado",
                description=f"Cargo {role.mention} foi adicionado a {user.mention}",
                color=0xffa500
            )
            embed.add_field(name="⏱️ Duração:", value=time_display, inline=True)
            embed.add_field(name="📅 Expira em:", value=f"<t:{int(expires_at.timestamp())}:R>", inline=True)
            embed.set_footer(text=f"Executado por: {author.display_name}")
            
            await self._send_response(ctx_or_interaction, embed=embed)
            
        except discord.Forbidden:
            await self._send_response(ctx_or_interaction, "❌ Não tenho permissão para gerenciar este cargo!")
        except Exception as e:
            await self._send_response(ctx_or_interaction, f"❌ Erro ao adicionar cargo temporário: {e}")
    
    async def add_temporary_role_seconds(self, ctx_or_interaction, user: discord.Member, role: discord.Role, seconds: int):
        try:
            if not self.can_manage_role(role):
                return await self._send_response(ctx_or_interaction, "❌ Este cargo não pode ser gerenciado pelo bot!")
            
            if seconds <= 0 or seconds > 86400:  # Max 24 hours in seconds
                return await self._send_response(ctx_or_interaction, "❌ Tempo deve ser entre 1 e 86400 segundos (24 horas)!")
            
            if role in user.roles:
                return await self._send_response(ctx_or_interaction, f"❌ {user.mention} já possui o cargo {role.mention}!")
            
            author = ctx_or_interaction.user if hasattr(ctx_or_interaction, 'user') else ctx_or_interaction.author
            await user.add_roles(role, reason=f"Cargo temporário adicionado por {author}")
            
            expires_at = datetime.now() + timedelta(seconds=seconds)
            self.bot.db_manager.add_temporary_role(user.id, role.id, expires_at)
            
            embed = discord.Embed(
                title="⏰ Cargo Temporário Adicionado",
                description=f"Cargo {role.mention} foi adicionado a {user.mention}",
                color=0xffa500
            )
            embed.add_field(name="⏱️ Duração:", value=f"{seconds} segundos", inline=True)
            embed.add_field(name="📅 Expira em:", value=f"<t:{int(expires_at.timestamp())}:R>", inline=True)
            embed.set_footer(text=f"Executado por: {author.display_name}")
            
            await self._send_response(ctx_or_interaction, embed=embed)
            
        except discord.Forbidden:
            await self._send_response(ctx_or_interaction, "❌ Não tenho permissão para gerenciar este cargo!")
        except Exception as e:
            await self._send_response(ctx_or_interaction, f"❌ Erro ao adicionar cargo temporário: {e}")
    
    async def _send_response(self, ctx_or_interaction, content=None, embed=None):
        """Helper method to send response to both ctx and interaction"""
        try:
            if hasattr(ctx_or_interaction, 'response') and hasattr(ctx_or_interaction, 'user'):
                # It's an interaction
                if ctx_or_interaction.response.is_done():
                    if embed:
                        await ctx_or_interaction.followup.send(embed=embed)
                    else:
                        await ctx_or_interaction.followup.send(content)
                else:
                    if embed:
                        await ctx_or_interaction.response.send_message(embed=embed)
                    else:
                        await ctx_or_interaction.response.send_message(content)
            else:
                # It's a context
                if embed:
                    await ctx_or_interaction.send(embed=embed)
                else:
                    await ctx_or_interaction.send(content)
        except Exception as e:
            print(f"❌ Erro ao enviar resposta: {e}")
    
    async def check_expired_roles(self):
        try:
            expired_roles = self.bot.db_manager.get_expired_roles()
            
            for role_data in expired_roles:
                try:
                    guild = self.bot.get_guild(SERVER_CONFIG['GUILD_ID'])
                    if not guild:
                        continue
                    
                    user = guild.get_member(role_data['user_id'])
                    role = guild.get_role(role_data['role_id'])
                    
                    if user and role and role in user.roles:
                        await user.remove_roles(role, reason="Cargo temporário expirado")
                        
                        try:
                            embed = discord.Embed(
                                title="⏰ Cargo Temporário Expirado",
                                description=f"O cargo **{role.name}** foi removido automaticamente.",
                                color=0xff0000
                            )
                            await user.send(embed=embed)
                        except discord.Forbidden:
                            pass
                    
                    self.bot.db_manager.remove_temporary_role(role_data['user_id'], role_data['role_id'])
                    
                except Exception as e:
                    print(f"❌ Erro ao remover cargo temporário: {e}")
                    
        except Exception as e:
            print(f"❌ Erro ao verificar cargos expirados: {e}")
    
    def can_manage_role(self, role: discord.Role) -> bool:
        manageable_roles = SERVER_CONFIG.get('MANAGEABLE_ROLES', [])
        
        if not manageable_roles:
            return role < role.guild.me.top_role
        
        return role.id in manageable_roles and role < role.guild.me.top_role
    
    def parse_time_duration(self, time_str: str) -> Optional[timedelta]:
        try:
            match = re.match(r'^(\d+)([hdw])$', time_str.lower())
            if not match:
                return None
            
            amount = int(match.group(1))
            unit = match.group(2)
            
            if unit == 'h':
                return timedelta(hours=amount)
            elif unit == 'd':
                return timedelta(days=amount)
            elif unit == 'w':
                return timedelta(weeks=amount)
            
            return None
            
        except Exception:
            return None

"""
MIT License
Copyright (c) 2026 Paulo Roberto Duarte Freitas
"""
