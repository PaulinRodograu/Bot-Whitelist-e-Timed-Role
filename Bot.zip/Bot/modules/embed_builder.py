import discord
from config.bot_config import EMBED_CONFIGS, MESSAGES
from config.perguntas_config import PERGUNTAS_CONFIG

class EmbedBuilder:
    def __init__(self):
        pass
    
    def create_embed_from_config(self, config_key: str, **kwargs) -> discord.Embed:
        config = EMBED_CONFIGS.get(config_key, {})
        
        embed = discord.Embed(
            title=config.get('title', ''),
            description=config.get('description', '').format(**kwargs),
            color=config.get('color', 0x2b2d31)
        )
        
        if config.get('image'):
            embed.set_image(url=config['image'])
        
        if config.get('thumbnail'):
            embed.set_thumbnail(url=config['thumbnail'])
        
        footer_text = config.get('footer', '')
        footer_icon = config.get('footer_icon', '')
        if footer_text:
            if footer_icon:
                embed.set_footer(text=footer_text, icon_url=footer_icon)
            else:
                embed.set_footer(text=footer_text)
        
        return embed
    
    def create_panel_embed(self) -> discord.Embed:
        return self.create_embed_from_config('PAINEL_PRINCIPAL')
    
    def create_dm_confirmation_embed(self) -> discord.Embed:
        return self.create_embed_from_config('CONFIRMACAO_DM')
    
    def create_question_embed(self, question_data: dict, question_number: int, total_questions: int) -> discord.Embed:
        # IMPORTANTE: Embed personalizado para perguntas - Mantenha este comentário para personalização
        embed = discord.Embed(
            title=question_data['title'],
            description=question_data['description'],
            color=0x2b2d31
        )
        
        embed.set_footer(text=f"Pergunta {question_number}/{total_questions} • Sistema de Whitelist")
        
        if question_data['class'] == 'select':
            options_text = ""
            for i in range(1, 26):
                option_key = f"opcao{i}"
                if option_key in question_data:
                    options_text += f"**{i}.** {question_data[option_key]}\n"
            
            if options_text:
                embed.add_field(name="📋 Opções:", value=options_text, inline=False)
        
        return embed
    
    def create_form_embed(self, user: discord.Member, answers: dict) -> discord.Embed:
        try:
            print(f"🔄 Criando embed de formulário para {user}")
            
            # IMPORTANTE: Embed personalizado para formulários - Mantenha este comentário para personalização
            embed = discord.Embed(
                title="📝 Nova Whitelist Recebida",
                description=f"**Usuário:** {user.mention} ({user.display_name})\n**ID:** {user.id}",
                color=0xFFFF00,
                timestamp=discord.utils.utcnow()
            )
            
            print(f"✅ Embed base criado")
            
            embed.set_thumbnail(url=user.display_avatar.url)
            print(f"✅ Thumbnail definida")
            
            for i, (question, answer) in enumerate(answers.items(), 1):
                if len(str(answer)) > 1024:
                    answer = str(answer)[:1021] + "..."
                
                embed.add_field(
                    name=f"**{i}.** {question}",
                    value=str(answer) if answer else "Não respondido",
                    inline=False
                )
            
            print(f"✅ {len(answers)} campos adicionados ao embed")
            
            embed.set_footer(text="Sistema de Whitelist • Clique no botão para responder")
            print(f"✅ Footer definido")
            
            print(f"✅ Embed de formulário criado com sucesso para {user}")
            return embed
            
        except Exception as e:
            print(f"❌ Erro ao criar embed de formulário para {user}: {e}")
            import traceback
            traceback.print_exc()
            # Retorna um embed básico em caso de erro
            return discord.Embed(
                title="📝 Nova Whitelist Recebida",
                description=f"**Usuário:** {user.mention} ({user.display_name})\n**ID:** {user.id}",
                color=0xFFFF00
            )
    
    def create_help_embed(self) -> discord.Embed:
        embed = discord.Embed(
            title="❓ Comandos Disponíveis",
            description="Lista de todos os comandos do bot e como usá-los:",
            color=0x0099ff
        )
        
        commands = [
            ("cc.wl [tipo]", "Lista todas as whitelists ativas e threads"),
            ("cc.role-adicionar @usuário @cargo", "Adiciona um cargo a um usuário"),
            ("cc.role-remover @usuário @cargo", "Remove um cargo de um usuário"),
            ("cc.role-listar @usuário", "Lista todos os cargos de um usuário"),
            ("cc.role-temporario @usuário @cargo [tempo]", "Adiciona cargo temporário (ex: 1h, 1d, 1w)"),
            ("cc.help", "Mostra esta mensagem de ajuda"),
            ("cc.ping", "Testa a conexão do bot"),
            ("os outros comandos só estão disponíveis no slash")
        ]
        
        for command, description in commands:
            embed.add_field(
                name=f"`{command}`",
                value=description,
                inline=False
            )
        
        embed.set_footer(text="Sistema de Whitelist • Use os comandos com responsabilidade")
        
        return embed
    
    def create_role_list_embed(self, user: discord.Member, roles: list) -> discord.Embed:
        embed = discord.Embed(
            title=f"📋 Cargos de {user.display_name}",
            description=f"**Usuário:** {user.mention}\n**ID:** {user.id}",
            color=0x2b2d31
        )
        
        embed.set_thumbnail(url=user.display_avatar.url)
        
        if roles:
            roles_text = "\n".join([f"• {role.mention}" for role in roles])
            embed.add_field(name="🎭 Cargos:", value=roles_text, inline=False)
        else:
            embed.add_field(name="🎭 Cargos:", value="Nenhum cargo encontrado", inline=False)
        
        embed.set_footer(text="Sistema de Gerenciamento de Cargos")
        
        return embed
    
    def create_whitelist_list_embed(self, active_whitelists: list) -> discord.Embed:
        embed = discord.Embed(
            title="📋 Whitelists Ativas",
            description="Lista de todas as whitelists em andamento:",
            color=0x2b2d31
        )
        
        if active_whitelists:
            for i, wl in enumerate(active_whitelists, 1):
                user_info = f"**Usuário:** <@{wl['user_id']}>\n"
                user_info += f"**Pergunta atual:** {wl.get('current_question', 0) + 1}/{len(PERGUNTAS_CONFIG)}\n"
                user_info += f"**Iniciado:** <t:{int(wl['started_at'])}:R>"
                
                embed.add_field(
                    name=f"#{i}",
                    value=user_info,
                    inline=True
                )
        else:
            embed.add_field(
                name="📭 Nenhuma whitelist ativa",
                value="Não há whitelists em andamento no momento.",
                inline=False
            )
        
        embed.set_footer(text="Sistema de Whitelist")
        
        return embed

"""
MIT License
Copyright (c) 2026 Paulo Roberto Duarte Freitas
"""
