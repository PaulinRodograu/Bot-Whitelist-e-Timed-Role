import discord
import json
import asyncio
from datetime import datetime, timedelta
from config.servidor_config import SERVER_CONFIG, COMMAND_PERMISSIONS

class ModerationManager:
    def __init__(self, bot):
        self.bot = bot
        self.moderation_data_file = 'data/moderation_actions.json'
        self.temp_roles_file = 'data/temp_roles.json'
        self.ensure_files_exist()
        
    def ensure_files_exist(self):
        import os
        os.makedirs('data', exist_ok=True)
        
        for file_path in [self.moderation_data_file, self.temp_roles_file]:
            if not os.path.exists(file_path):
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump({}, f, ensure_ascii=False, indent=2)
    
    def has_moderation_permission(self, member: discord.Member) -> bool:
        """Check if member has permission to use moderation buttons"""
        try:
            # Get all role IDs that can use any command
            allowed_role_ids = set()
            for command_roles in COMMAND_PERMISSIONS.values():
                allowed_role_ids.update(command_roles)
            
            # Check if member has any of the allowed roles
            member_role_ids = {role.id for role in member.roles}
            return bool(allowed_role_ids.intersection(member_role_ids))
            
        except Exception as e:
            print(f"❌ Erro ao verificar permissões: {e}")
            return False
    
    def save_moderation_action(self, message_id, user_id, moderator_id, action, reason=None):
        try:
            # Salva no arquivo de ações de moderação (legacy)
            with open(self.moderation_data_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except:
            data = {}
        
        data[str(message_id)] = {
            'user_id': user_id,
            'moderator_id': moderator_id,
            'action': action,
            'reason': reason,
            'timestamp': datetime.now().isoformat()
        }
        
        if len(data) > 100:
            oldest_key = min(data.keys(), key=lambda k: data[k]['timestamp'])
            del data[oldest_key]
        
        with open(self.moderation_data_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        # ATUALIZA O STATUS NO ARQUIVO PRINCIPAL DE MODERAÇÃO
        try:
            self.bot.db_manager.update_moderation_status(message_id, action, moderator_id, reason)
            print(f"✅ Status atualizado para '{action}' no moderation_data.json")
        except Exception as e:
            print(f"❌ Erro ao atualizar status no moderation_data.json: {e}")
    
    def get_moderation_action(self, message_id):
        try:
            with open(self.moderation_data_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return data.get(str(message_id))
        except:
            return None
    
    def save_temp_role(self, user_id, role_id, end_time):
        try:
            with open(self.temp_roles_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except:
            data = {}
        
        key = f"{user_id}_{role_id}"
        data[key] = {
            'user_id': user_id,
            'role_id': role_id,
            'end_time': end_time.isoformat()
        }
        
        with open(self.temp_roles_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def get_expired_temp_roles(self):
        try:
            with open(self.temp_roles_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except:
            return []
        
        now = datetime.now()
        expired = []
        
        for key, role_data in data.items():
            end_time = datetime.fromisoformat(role_data['end_time'])
            if now >= end_time:
                expired.append(role_data)
        
        return expired
    
    def remove_temp_role(self, user_id, role_id):
        try:
            with open(self.temp_roles_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except:
            return
        
        key = f"{user_id}_{role_id}"
        if key in data:
            del data[key]
            
            with open(self.temp_roles_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
    
    async def check_temp_roles(self):
        while not self.bot.is_closed():
            try:
                expired_roles = self.get_expired_temp_roles()
                
                for role_data in expired_roles:
                    guild = self.bot.get_guild(SERVER_CONFIG['GUILD_ID'])
                    if guild:
                        member = guild.get_member(role_data['user_id'])
                        role = guild.get_role(role_data['role_id'])
                        
                        if member and role and role in member.roles:
                            await member.remove_roles(role, reason="Cargo temporário expirado")
                            
                            logs_channel = guild.get_channel(SERVER_CONFIG.get('LOGS_CHANNEL_ID'))
                            if logs_channel:
                                embed = discord.Embed(
                                    title="🕒 Cargo Temporário Removido",
                                    color=0xFFA500,
                                    timestamp=datetime.now()
                                )
                                embed.add_field(name="Usuário", value=f"{member.mention}", inline=True)
                                embed.add_field(name="Cargo", value=f"{role.name}", inline=True)
                                embed.add_field(name="Motivo", value="Tempo expirado", inline=False)
                                
                                await logs_channel.send(embed=embed)
                        
                        self.remove_temp_role(role_data['user_id'], role_data['role_id'])
                
            except Exception as e:
                print(f"Erro ao verificar cargos temporários: {e}")
            
            await asyncio.sleep(60)

class ModerationView(discord.ui.View):
    def __init__(self, user_id, user_data, moderation_manager):
        super().__init__(timeout=None)
        self.user_id = user_id
        self.user_data = user_data
        self.moderation_manager = moderation_manager
        
        self.add_item(ApproveButton())
        self.add_item(MessageButton())
        self.add_item(DenyButton())

class ApproveButton(discord.ui.Button):
    def __init__(self):
        super().__init__(
            style=discord.ButtonStyle.success,
            label="✅ Aprovar",
            custom_id="persistent_approve_whitelist"
        )
    
    async def callback(self, interaction: discord.Interaction):
        if not self.view.moderation_manager.has_moderation_permission(interaction.user):
            await interaction.response.send_message(
                "❌ Você não tem autorização para usar este botão. É necessário ter acesso a pelo menos um comando de moderação.",
                ephemeral=True
            )
            return
        
        existing_action = self.view.moderation_manager.get_moderation_action(interaction.message.id)
        if existing_action:
            await interaction.response.send_message(
                f"⚠️ Esta whitelist já foi processada ({existing_action['action']}) por <@{existing_action['moderator_id']}>",
                ephemeral=True
            )
            return
        
        view = ApprovalOptionsView(self.view.user_id, self.view.user_data, self.view.moderation_manager, interaction.message)
        
        embed = discord.Embed(
            title="🟢 Opções de Aprovação",
            description="Escolha como deseja aprovar esta whitelist:",
            color=0x00FF00
        )
        
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

class MessageButton(discord.ui.Button):
    def __init__(self):
        super().__init__(
            style=discord.ButtonStyle.secondary,
            label="💬 Mensagem",
            custom_id="persistent_message_user"
        )
    
    async def callback(self, interaction: discord.Interaction):
        if not self.view.moderation_manager.has_moderation_permission(interaction.user):
            await interaction.response.send_message(
                "❌ Você não tem autorização para usar este botão. É necessário ter acesso a pelo menos um comando de moderação.",
                ephemeral=True
            )
            return
        
        modal = MessageModal(self.view.user_id)
        await interaction.response.send_modal(modal)

class DenyButton(discord.ui.Button):
    def __init__(self):
        super().__init__(
            style=discord.ButtonStyle.danger,
            label="❌ Negar",
            custom_id="persistent_deny_whitelist"
        )
    
    async def callback(self, interaction: discord.Interaction):
        if not self.view.moderation_manager.has_moderation_permission(interaction.user):
            await interaction.response.send_message(
                "❌ Você não tem autorização para usar este botão. É necessário ter acesso a pelo menos um comando de moderação.",
                ephemeral=True
            )
            return
        
        existing_action = self.view.moderation_manager.get_moderation_action(interaction.message.id)
        if existing_action:
            await interaction.response.send_message(
                f"⚠️ Esta whitelist já foi processada ({existing_action['action']}) por <@{existing_action['moderator_id']}>",
                ephemeral=True
            )
            return
        
        modal = DenyModal(self.view.user_id, self.view.user_data, self.view.moderation_manager, interaction.message)
        await interaction.response.send_modal(modal)

class ApprovalOptionsView(discord.ui.View):
    def __init__(self, user_id, user_data, moderation_manager, original_message):
        super().__init__(timeout=300)
        self.user_id = user_id
        self.user_data = user_data
        self.moderation_manager = moderation_manager
        self.original_message = original_message
    
    @discord.ui.button(label="✅ Aprovar Sem Motivo", style=discord.ButtonStyle.success)
    async def approve_no_reason(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.process_approval(interaction, None)
    
    @discord.ui.button(label="✅ Aprovar Com Motivo", style=discord.ButtonStyle.success)
    async def approve_with_reason(self, interaction: discord.Interaction, button: discord.ui.Button):
        modal = ApprovalModal(self.user_id, self.user_data, self.moderation_manager, self.original_message)
        await interaction.response.send_modal(modal)
    
    async def process_approval(self, interaction, reason):
        guild = interaction.guild
        user = guild.get_member(self.user_id)
        
        if not user:
            await interaction.followup.send("❌ Usuário não encontrado no servidor!", ephemeral=True)
            return
        
        approved_role_ids = SERVER_CONFIG.get('APPROVED_ROLE_ID', ())
        # Convert to tuple if it's not already (for safety)
        if not isinstance(approved_role_ids, (tuple, list)):
            approved_role_ids = (approved_role_ids,)
        
        roles_added = []
        
        if approved_role_ids:
            for role_id in approved_role_ids:
                approved_role = guild.get_role(role_id)
                if approved_role and approved_role not in user.roles:
                    try:
                        await user.add_roles(approved_role, reason=f"Whitelist aprovada por {interaction.user}")
                        roles_added.append(approved_role.name)
                        print(f"✅ Cargo {approved_role.name} adicionado ao usuário {user}")
                    except Exception as e:
                        print(f"❌ Erro ao adicionar cargo {approved_role.name}: {e}")
        
        if roles_added:
            print(f"✅ Cargos adicionados: {', '.join(roles_added)}")
        
        self.moderation_manager.save_moderation_action(
            self.original_message.id, self.user_id, interaction.user.id, "approved", reason
        )
        
        await self.send_approval_log(interaction, user, reason)
        
        try:
            disabled_embed = self.original_message.embeds[0].copy()
            disabled_embed.color = 0x00FF00
            disabled_embed.add_field(
                name="✅ Status", 
                value=f"Aprovado por {interaction.user.mention}", 
                inline=False
            )
            if reason:
                disabled_embed.add_field(name="Motivo", value=reason, inline=False)
            
            roles_status = ", ".join(roles_added) if roles_added else "Não configurado"
            disabled_embed.add_field(name="📌 Cargos Adicionados:", value=roles_status, inline=True)
            
            disabled_view = DisabledModerationView("approved")
            await self.original_message.edit(embed=disabled_embed, view=disabled_view)
        except Exception as e:
            print(f"❌ Erro ao editar mensagem original: {e}")
        
        try:
            dm_embed = discord.Embed(
                title="✅ Whitelist Aprovada!",
                description="Sua whitelist foi aprovada pela moderação!",
                color=0x00FF00
            )
            dm_embed.add_field(name="Motivo", value=reason, inline=False)
            dm_embed.set_footer(text=f"Aprovado por: {interaction.user.display_name}")
            
            await user.send(embed=dm_embed)
        except:
            print(f"❌ Não foi possível enviar DM para {user}")
        
        if not reason:
            await interaction.response.send_message("✅ Whitelist aprovada com sucesso!", ephemeral=True)

    async def send_approval_log(self, interaction, user, reason):
        try:
            guild = interaction.guild
            logs_channel = guild.get_channel(SERVER_CONFIG.get('LOGS_APPROVED_CHANNEL_ID'))
            if not logs_channel:
                return
            
            embed = discord.Embed(
                title="**✅ Whitelist Aprovada!**",
                description="**Parabéns, sua história foi aprovada!**\n**Que Veldan seja palco das suas maiores aventuras.**",
                color=0x00FF00,  # Green color
                timestamp=datetime.now()
            )
            
            embed.add_field(name="👤 Usuário:", value=f"{user.mention}", inline=True)
            embed.add_field(name="📛 Username:", value=f"{user.name}", inline=True)
            embed.add_field(name="🆔 ID:", value=f"{user.id}", inline=True)
            
            embed.add_field(name="🛡️ Moderador:", value=f"{interaction.user.mention}", inline=True)
            
            approved_role_ids = SERVER_CONFIG.get('APPROVED_ROLE_ID', ())
            # Convert to tuple if it's not already (for safety)
            if not isinstance(approved_role_ids, (tuple, list)):
                approved_role_ids = (approved_role_ids,)
            
            roles_status = ", ".join([guild.get_role(role_id).name for role_id in approved_role_ids if guild.get_role(role_id)]) if approved_role_ids else "Não configurado"
            embed.add_field(name="📌 Cargos Adicionados:", value=roles_status, inline=True)
            
            embed.add_field(name="📅 Enviado em", value=f"<t:{int(datetime.now().timestamp())}:F>", inline=True)
            
            if reason:
                embed.add_field(name="Motivo", value=reason, inline=False)
            
            embed.set_footer(text=f"ID do usuário: {user.id} | ID do moderador: {interaction.user.id}")
            embed.set_image(url="https://media.discordapp.net/attachments/1420399703144796242/1420403642221203566/image907.png?ex=68d5457a&is=68d3f3fa&hm=403df582d5cbd5972c239be7a683e6f981dec1070013d9a98e0d7959df69491f&=&format=webp&quality=lossless&width=1214&height=228")
            
            await logs_channel.send(embed=embed)
            
        except Exception as e:
            print(f"❌ Erro ao enviar log de aprovação: {e}")

class ApprovalModal(discord.ui.Modal):
    def __init__(self, user_id, user_data, moderation_manager, original_message):
        super().__init__(title="Motivo da Aprovação")
        self.user_id = user_id
        self.user_data = user_data
        self.moderation_manager = moderation_manager
        self.original_message = original_message
        
        self.reason_input = discord.ui.TextInput(
            label="Motivo da Aprovação",
            placeholder="Digite o motivo da aprovação...",
            style=discord.TextStyle.paragraph,
            max_length=500,
            required=True
        )
        self.add_item(self.reason_input)
    
    async def on_submit(self, interaction: discord.Interaction):
        reason = self.reason_input.value
        
        guild = interaction.guild
        user = guild.get_member(self.user_id)
        
        if not user:
            await interaction.response.send_message("❌ Usuário não encontrado no servidor!", ephemeral=True)
            return
        
        approved_role_ids = SERVER_CONFIG.get('APPROVED_ROLE_ID', ())
        # Convert to tuple if it's not already (for safety)
        if not isinstance(approved_role_ids, (tuple, list)):
            approved_role_ids = (approved_role_ids,)
        
        roles_added = []

        if approved_role_ids:
            for role_id in approved_role_ids:
                approved_role = guild.get_role(role_id)
                if approved_role and approved_role not in user.roles:
                    try:
                        await user.add_roles(approved_role, reason=f"Whitelist aprovada por {interaction.user}: {reason}")
                        roles_added.append(approved_role.name)
                        print(f"✅ Cargo {approved_role.name} adicionado ao usuário {user}")
                    except Exception as e:
                        print(f"❌ Erro ao adicionar cargo {approved_role.name}: {e}")
        
        if roles_added:
            print(f"✅ Cargos adicionados: {', '.join(roles_added)}")
        
        self.moderation_manager.save_moderation_action(
            self.original_message.id, self.user_id, interaction.user.id, "approved", reason
        )
        
        await self.send_approval_log(interaction, user, reason)
        
        try:
            disabled_embed = self.original_message.embeds[0].copy()
            disabled_embed.color = 0x00FF00
            disabled_embed.add_field(
                name="✅ Status", 
                value=f"Aprovado por {interaction.user.mention}", 
                inline=False
            )
            disabled_embed.add_field(name="Motivo", value=reason, inline=False)
            
            roles_status = ", ".join(roles_added) if roles_added else "Não configurado"
            disabled_embed.add_field(name="📌 Cargos Adicionados:", value=roles_status, inline=True)
            
            disabled_view = DisabledModerationView("approved")
            await self.original_message.edit(embed=disabled_embed, view=disabled_view)
        except Exception as e:
            print(f"❌ Erro ao editar mensagem original: {e}")
        
        try:
            dm_embed = discord.Embed(
                title="✅ Whitelist Aprovada!",
                description="Sua whitelist foi aprovada pela moderação!",
                color=0x00FF00
            )
            dm_embed.add_field(name="Motivo", value=reason, inline=False)
            dm_embed.set_footer(text=f"Aprovado por: {interaction.user.display_name}")
            
            await user.send(embed=dm_embed)
        except:
            print(f"❌ Não foi possível enviar DM para {user}")
        
        await interaction.response.send_message("✅ Whitelist aprovada com sucesso!", ephemeral=True)

    async def send_approval_log(self, interaction, user, reason):
        try:
            guild = interaction.guild
            logs_channel = guild.get_channel(SERVER_CONFIG.get('LOGS_APPROVED_CHANNEL_ID'))
            if not logs_channel:
                return
            
            embed = discord.Embed(
                title="**✅ Whitelist Aprovada!**",
                description="**Parabéns, sua história foi aprovada!**\n**Que Veldan seja palco das suas maiores aventuras.**",
                color=0x00FF00,  # Green color
                timestamp=datetime.now()
            )
            
            embed.add_field(name="👤 Usuário:", value=f"{user.mention}", inline=True)
            embed.add_field(name="📛 Username:", value=f"{user.name}", inline=True)
            embed.add_field(name="🆔 ID:", value=f"{user.id}", inline=True)
            
            embed.add_field(name="🛡️ Moderador:", value=f"{interaction.user.mention}", inline=True)
            
            approved_role_ids = SERVER_CONFIG.get('APPROVED_ROLE_ID', ())
            # Convert to tuple if it's not already (for safety)
            if not isinstance(approved_role_ids, (tuple, list)):
                approved_role_ids = (approved_role_ids,)
            
            roles_status = ", ".join([guild.get_role(role_id).name for role_id in approved_role_ids if guild.get_role(role_id)]) if approved_role_ids else "Não configurado"
            embed.add_field(name="📌 Cargos Adicionados:", value=roles_status, inline=True)
            
            embed.add_field(name="📅 Enviado em", value=f"<t:{int(datetime.now().timestamp())}:F>", inline=True)
            
            if reason:
                embed.add_field(name="Motivo", value=reason, inline=False)
            
            embed.set_footer(text=f"ID do usuário: {user.id} | ID do moderador: {interaction.user.id}")
            embed.set_image(url="https://media.discordapp.net/attachments/1420399703144796242/1420403642221203566/image907.png?ex=68d5457a&is=68d3f3fa&hm=403df582d5cbd5972c239be7a683e6f981dec1070013d9a98e0d7959df69491f&=&format=webp&quality=lossless&width=1214&height=228")
            
            await logs_channel.send(embed=embed)
            
        except Exception as e:
            print(f"❌ Erro ao enviar log de aprovação: {e}")

class DisabledModerationView(discord.ui.View):
    def __init__(self, status):
        super().__init__(timeout=None)
        
        if status == "approved":
            self.add_item(discord.ui.Button(
                style=discord.ButtonStyle.success,
                label="✅ Aprovado",
                disabled=True
            ))
        elif status == "denied":
            self.add_item(discord.ui.Button(
                style=discord.ButtonStyle.danger,
                label="❌ Negado",
                disabled=True
            ))

class MessageModal(discord.ui.Modal):
    def __init__(self, user_id):
        super().__init__(title="Enviar Mensagem")
        self.user_id = user_id
        
        self.message_input = discord.ui.TextInput(
            label="Mensagem",
            placeholder="Digite a mensagem para o usuário...",
            style=discord.TextStyle.paragraph,
            max_length=1000,
            required=True
        )
        self.add_item(self.message_input)
    
    async def on_submit(self, interaction: discord.Interaction):
        message = self.message_input.value
        
        guild = interaction.guild
        user = guild.get_member(self.user_id)
        
        if not user:
            await interaction.response.send_message("❌ Usuário não encontrado no servidor!", ephemeral=True)
            return
        
        try:
            dm_embed = discord.Embed(
                title="💬 Mensagem da Moderação",
                description=message,
                color=0x0099FF
            )
            dm_embed.set_footer(text=f"Enviado por: {interaction.user.display_name}")
            
            await user.send(embed=dm_embed)
            await interaction.response.send_message("✅ Mensagem enviada com sucesso!", ephemeral=True)
        except:
            await interaction.response.send_message("❌ Não foi possível enviar a mensagem para o usuário!", ephemeral=True)

class DenyModal(discord.ui.Modal):
    def __init__(self, user_id, user_data, moderation_manager, original_message):
        super().__init__(title="Motivo da Negação")
        self.user_id = user_id
        self.user_data = user_data
        self.moderation_manager = moderation_manager
        self.original_message = original_message
        
        self.reason_input = discord.ui.TextInput(
            label="Motivo da Negação",
            placeholder="Digite o motivo da negação...",
            style=discord.TextStyle.paragraph,
            max_length=500,
            required=True
        )
        self.add_item(self.reason_input)
    
    async def on_submit(self, interaction: discord.Interaction):
        reason = self.reason_input.value
        
        guild = interaction.guild
        user = guild.get_member(self.user_id)
        
        if not user:
            await interaction.response.send_message("❌ Usuário não encontrado no servidor!", ephemeral=True)
            return
        
        approved_role_ids = SERVER_CONFIG.get('APPROVED_ROLE_ID', ())
        # Convert to tuple if it's not already (for safety)
        if not isinstance(approved_role_ids, (tuple, list)):
            approved_role_ids = (approved_role_ids,)
        
        roles_removed = []
        
        if approved_role_ids:
            for role_id in approved_role_ids:
                approved_role = guild.get_role(role_id)
                if approved_role and approved_role in user.roles:
                    try:
                        await user.remove_roles(approved_role, reason=f"Whitelist rejeitada por {interaction.user}")
                        roles_removed.append(approved_role.name)
                        print(f"✅ Cargo {approved_role.name} removido do usuário {user}")
                    except Exception as e:
                        print(f"❌ Erro ao remover cargo {approved_role.name}: {e}")
        
        if roles_removed:
            print(f"✅ Cargos removidos: {', '.join(roles_removed)}")
        
        self.moderation_manager.save_moderation_action(
            self.original_message.id, self.user_id, interaction.user.id, "denied", reason
        )
        
        await self.send_denial_log(interaction, user, reason)
        
        try:
            disabled_embed = self.original_message.embeds[0].copy()
            disabled_embed.color = 0xFF0000
            disabled_embed.add_field(
                name="❌ Status", 
                value=f"Negado por {interaction.user.mention}", 
                inline=False
            )
            disabled_embed.add_field(name="Motivo", value=reason, inline=False)
            
            roles_status = ", ".join(roles_removed) if roles_removed else "Não configurado"
            disabled_embed.add_field(name="📌 Cargos Removidos:", value=roles_status, inline=True)
            
            disabled_view = DisabledModerationView("denied")
            await self.original_message.edit(embed=disabled_embed, view=disabled_view)
        except Exception as e:
            print(f"❌ Erro ao editar mensagem original: {e}")
        
        try:
            dm_embed = discord.Embed(
                title="❌ Whitelist Negada",
                description="Sua whitelist foi negada pela moderação.",
                color=0xFF0000
            )
            dm_embed.add_field(name="Motivo", value=reason, inline=False)
            dm_embed.set_footer(text=f"Negado por: {interaction.user.display_name}")
            
            await user.send(embed=dm_embed)
        except:
            print(f"❌ Não foi possível enviar DM para {user}")
        
        await interaction.response.send_message("❌ Whitelist negada com sucesso!", ephemeral=True)

    async def send_denial_log(self, interaction, user, reason):
        try:
            guild = interaction.guild
            logs_channel = guild.get_channel(SERVER_CONFIG.get('LOGS_DENIED_CHANNEL_ID'))
            if not logs_channel:
                return
            
            embed = discord.Embed(
                title="**🚫 Whitelist Negada!**",
                description="**Infelizmente, sua Whitelist foi negada. 😕**\n**Mas não desanime! Você poderá tentar novamente após 10 horas.**",
                color=0xFF0000,  # Red color
                timestamp=datetime.now()
            )
            
            embed.add_field(name="👤 Usuário:", value=f"{user.mention}", inline=True)
            embed.add_field(name="📛 Username:", value=f"{user.name}", inline=True)
            embed.add_field(name="🆔 ID:", value=f"{user.id}", inline=True)
            
            embed.add_field(name="🛡️ Moderador:", value=f"{interaction.user.mention}", inline=True)
            
            approved_role_ids = SERVER_CONFIG.get('APPROVED_ROLE_ID', ())
            # Convert to tuple if it's not already (for safety)
            if not isinstance(approved_role_ids, (tuple, list)):
                approved_role_ids = (approved_role_ids,)
            
            roles_status = ", ".join([guild.get_role(role_id).name for role_id in approved_role_ids if guild.get_role(role_id)]) if approved_role_ids else "Não configurado"
            embed.add_field(name="📌 Cargos Removidos:", value=roles_status, inline=True)
            
            embed.add_field(name="📅 Enviado em", value=f"<t:{int(datetime.now().timestamp())}:F>", inline=True)
            
            embed.add_field(name="Motivo", value=reason, inline=False)
            
            embed.set_footer(text=f"ID do usuário: {user.id} | ID do moderador: {interaction.user.id}")
            embed.set_image(url="https://media.discordapp.net/attachments/1420399703144796242/1420403641868619887/image8809.png?ex=68d5457a&is=68d3f3fa&hm=4f0b9a564fa7594d4ef2487c9de32839dc3f017fcb9e6685d59b891f2c4621e8&=&format=webp&quality=lossless&width=1214&height=298")
            
            await logs_channel.send(embed=embed)
            
        except Exception as e:
            print(f"❌ Erro ao enviar log de negação: {e}")

class ResponseModal(discord.ui.Modal):
    def __init__(self, bot, user_id):
        super().__init__(title="Responder Usuário")
        self.bot = bot
        self.user_id = user_id
        
        self.message_input = discord.ui.TextInput(
            label="Mensagem",
            placeholder="Digite sua resposta para o usuário...",
            style=discord.TextStyle.paragraph,
            max_length=1000,
            required=True
        )
        self.add_item(self.message_input)
    
    async def on_submit(self, interaction: discord.Interaction):
        message = self.message_input.value
        
        guild = interaction.guild
        user = guild.get_member(self.user_id)
        
        if not user:
            await interaction.response.send_message("❌ Usuário não encontrado no servidor!", ephemeral=True)
            return
        
        try:
            dm_embed = discord.Embed(
                title="💬 Resposta da Moderação",
                description=message,
                color=0x0099FF
            )
            dm_embed.set_footer(text=f"Enviado por: {interaction.user.display_name}")
            
            await user.send(embed=dm_embed)
            await interaction.response.send_message("✅ Resposta enviada com sucesso!", ephemeral=True)
        except:
            await interaction.response.send_message("❌ Não foi possível enviar a resposta para o usuário!", ephemeral=True)

"""
MIT License
Copyright (c) 2026 Paulo Roberto Duarte Freitas
"""
