import discord
from discord.ext import commands
import asyncio
from datetime import datetime, timedelta
from typing import Optional, Dict, List

from config.bot_config import MESSAGES, BOT_CONFIG
from config.servidor_config import SERVER_CONFIG, COMMAND_PERMISSIONS
from config.perguntas_config import PERGUNTAS_CONFIG, VALIDATION_CONFIG, TIMEOUT_CONFIG
from modules.moderation_manager import ModerationView

class WhitelistHandler:
    def __init__(self, bot):
        self.bot = bot
        self.active_sessions = {}
        self.file_listeners = {}
    
    async def start_whitelist(self, user: discord.Member) -> bool:
        try:
            if self.bot.db_manager.get_whitelist_session(user.id):
                return False
            
            if self.bot.db_manager.is_user_on_cooldown(user.id):
                return False
            
            session_data = {
                'user_id': user.id,
                'current_question': 0,
                'answers': {},
                'status': 'active'
            }
            
            self.bot.db_manager.add_whitelist_session(user.id, session_data)
            await self.send_question(user, 0)
            return True
            
        except Exception as e:
            print(f"❌ Erro ao iniciar whitelist para {user}: {e}")
            return False
    
    async def send_question(self, user: discord.Member, question_index: int):
        try:
            if question_index >= len(PERGUNTAS_CONFIG):
                await self.complete_whitelist(user)
                return
            
            question = PERGUNTAS_CONFIG[question_index]
            
            embed = self.bot.embed_builder.create_question_embed(
                question, question_index + 1, len(PERGUNTAS_CONFIG)
            )
            
            view = None
            if question['class'] == 'texto':
                view = TextQuestionView(self, user, question_index)
            elif question['class'] == 'select':
                view = SelectQuestionView(self, user, question_index, question)
            elif question['class'] == 'arquivo':
                await user.send(embed=embed)
                await self.setup_file_listener(user, question_index)
                return
            
            await user.send(embed=embed, view=view)
            
        except discord.Forbidden:
            print(f"❌ Não foi possível enviar DM para {user}")
        except Exception as e:
            print(f"❌ Erro ao enviar pergunta para {user}: {e}")
    
    async def setup_file_listener(self, user: discord.Member, question_index: int):
        try:
            self.file_listeners[user.id] = {
                'question_index': question_index,
                'waiting': True,
                'timeout_task': None,
                'files_received': 0,  # Track number of files received for question 8
                'warn_task': None  # Task for timeout warning
            }
            
            timeout_task = asyncio.create_task(self.file_timeout_handler(user, question_index))
            self.file_listeners[user.id]['timeout_task'] = timeout_task
            
            if question_index == 7:  # Question 8 (images)
                warn_task = asyncio.create_task(self.warn_timeout_handler(user))
                self.file_listeners[user.id]['warn_task'] = warn_task
                await user.send("📸 **Envie até 5 imagens do seu modelo e skin!**\n⏰ Você tem 10 minutos para enviar todas as imagens.")
            else:
                await user.send("📎 **Envie seu arquivo diretamente nesta conversa** (sem usar botões)")
            
        except Exception as e:
            print(f"❌ Erro ao configurar listener de arquivo para {user}: {e}")
    
    async def warn_timeout_handler(self, user: discord.Member):
        try:
            warn_time = TIMEOUT_CONFIG.get('WARN_BEFORE_TIMEOUT', 60)  # Default 60 seconds
            await asyncio.sleep(TIMEOUT_CONFIG['FILE_TIMEOUT'] - warn_time)
            
            if user.id in self.file_listeners and self.file_listeners[user.id]['waiting']:
                remaining_files = 5 - self.file_listeners[user.id].get('files_received', 0)
                warning_msg = f"⚠️ **AVISO DE TEMPO!**\n"
                if remaining_files > 0:
                    warning_msg += f"• Você ainda pode enviar mais {remaining_files} imagem(ns)\n"
                warning_msg += f"• Apenas {warn_time} segundos restantes!\n"
                warning_msg += "• Envie suas imagens rapidamente ou o tempo irá expirar!"
                
                await user.send(warning_msg)
            
        except Exception as e:
            print(f"❌ Erro no aviso de timeout para {user}: {e}")

    async def file_timeout_handler(self, user: discord.Member, question_index: int):
        try:
            await asyncio.sleep(TIMEOUT_CONFIG['FILE_TIMEOUT'])
            
            if user.id in self.file_listeners and self.file_listeners[user.id]['waiting']:
                timeout_msg = "⏰ **Tempo esgotado!**\n"
                
                if question_index == 7:  # Question 8 (images)
                    files_received = self.file_listeners[user.id].get('files_received', 0)
                    if files_received == 0:
                        timeout_msg += "Você não enviou nenhuma imagem no tempo limite."
                    else:
                        timeout_msg += f"Você enviou {files_received} imagem(ns) de 5 possíveis."
                
                timeout_msg += "\nUse o comando para reiniciar a whitelist."
                await user.send(timeout_msg)
                
                if user.id in self.file_listeners:
                    # Cancel the warning task if it exists
                    if self.file_listeners[user.id].get('warn_task'):
                        self.file_listeners[user.id]['warn_task'].cancel()
                    del self.file_listeners[user.id]
                
                self.bot.db_manager.remove_whitelist_session(user.id)
                
        except Exception as e:
            print(f"❌ Erro no timeout de arquivo para {user}: {e}")
    
    async def handle_file_message(self, message: discord.Message):
        try:
            user_id = message.author.id
            
            if user_id not in self.file_listeners or not self.file_listeners[user_id]['waiting']:
                return False
            
            if not message.attachments:
                await message.reply("❌ Por favor, envie um arquivo!")
                return False
            
            question_index = self.file_listeners[user_id]['question_index']
            processed_attachments = []
            
            # Check if this is the question that allows multiple images (question 8 - index 7)
            allows_multiple = question_index == 7  # Question 8 (0-indexed)
            max_files = 5 if allows_multiple else 1
            
            # For question 8, check how many files were already received
            if allows_multiple:
                files_received = self.file_listeners[user_id].get('files_received', 0)
                files_remaining = max_files - files_received
                
                if files_remaining <= 0:
                    await message.reply("❌ Você já enviou o número máximo de imagens permitidas (5)!")
                    return False
                
                # Update number of files that can still be processed
                max_current_files = min(len(message.attachments), files_remaining)
                attachments_to_process = message.attachments[:max_current_files]
            else:
                attachments_to_process = message.attachments[:1]
            
            for attachment in attachments_to_process:
                if attachment.size > VALIDATION_CONFIG['MAX_FILE_SIZE_MB'] * 1024 * 1024:
                    await message.reply(f"❌ Arquivo '{attachment.filename}' muito grande! Máximo: {VALIDATION_CONFIG['MAX_FILE_SIZE_MB']}MB")
                    return False
                
                allowed_types = VALIDATION_CONFIG.get('ACCEPTED_FILE_TYPES', [])
                if allowed_types:
                    file_ext = '.' + attachment.filename.split('.')[-1].lower()
                    if file_ext not in allowed_types:
                        await message.reply(f"❌ Tipo de arquivo '{attachment.filename}' não permitido! Tipos aceitos: {', '.join(allowed_types)}")
                        return False
                
                processed_attachments.append({
                    'filename': attachment.filename,
                    'url': attachment.url
                })
            
            # Create the answer string with all attachments
            if allows_multiple:
                # Update the count of files received
                current_files = self.file_listeners[user_id].get('files_received', 0)
                new_total = current_files + len(processed_attachments)
                self.file_listeners[user_id]['files_received'] = new_total
                
                # Format multiple files with line breaks
                answer_parts = []
                for i, att in enumerate(processed_attachments, current_files + 1):
                    answer_parts.append(f"**Imagem {i}:** [{att['filename']}]({att['url']})")
                
                # If we already had some files, append to existing answer
                if current_files > 0:
                    session = self.bot.db_manager.get_whitelist_session(user_id)
                    if session and 'answers' in session:
                        existing_answer = session['answers'].get(PERGUNTAS_CONFIG[question_index]['title'], '')
                        if existing_answer:
                            answer_parts.insert(0, existing_answer)
                
                answer = "\n".join(answer_parts)
                
                # Send confirmation message with remaining slots
                remaining = max_files - new_total
                status = f"✅ Recebi {len(processed_attachments)} nova(s) imagem(ns)!\n"
                status += f"📸 Total: {new_total} de 5 imagens\n"
                
                if remaining > 0:
                    status += f"🔄 Você ainda pode enviar mais {remaining} imagem(ns)!\n"
                else:
                    status += "✨ Todas as 5 imagens foram recebidas!\n"
                    # If all images are received, complete this question
                    if self.file_listeners[user_id]['timeout_task']:
                        self.file_listeners[user_id]['timeout_task'].cancel()
                    if self.file_listeners[user_id]['warn_task']:
                        self.file_listeners[user_id]['warn_task'].cancel()
                
                await message.reply(status)
            else:
                # Single file format
                att = processed_attachments[0]
                answer = f"[{att['filename']}]({att['url']})"
                await message.reply(f"✅ Arquivo '{att['filename']}' recebido com sucesso!")
            
            if self.file_listeners[user_id]['timeout_task']:
                self.file_listeners[user_id]['timeout_task'].cancel()
            
            del self.file_listeners[user_id]
            
            await self.process_answer(message.author, question_index, answer)
            
            return True
            
        except Exception as e:
            print(f"❌ Erro ao processar arquivo: {e}")
            return False
    
    async def handle_text_message_warning(self, message: discord.Message):
        try:
            user_id = message.author.id
            session = self.bot.db_manager.get_whitelist_session(user_id)
            
            if not session:
                return False
            
            current_question_index = session.get('current_question', 0)
            if current_question_index >= len(PERGUNTAS_CONFIG):
                return False
            
            question = PERGUNTAS_CONFIG[current_question_index]
            
            if question['class'] in ['texto', 'select']:
                await message.reply("⚠️ **Clique no botão para responder!** Não envie mensagens diretamente.")
                return True
            
            return False
            
        except Exception as e:
            print(f"❌ Erro ao verificar aviso de mensagem: {e}")
            return False
    
    async def process_answer(self, user: discord.Member, question_index: int, answer: str):
        try:
            if not self.validate_answer(question_index, answer):
                return False
            
            session = self.bot.db_manager.get_whitelist_session(user.id)
            if not session:
                return False
            
            question = PERGUNTAS_CONFIG[question_index]
            session['answers'][question['title']] = answer
            session['current_question'] = question_index + 1
            
            self.bot.db_manager.update_whitelist_session(user.id, session)
            await self.send_question(user, question_index + 1)
            
            return True
            
        except Exception as e:
            print(f"❌ Erro ao processar resposta de {user}: {e}")
            return False
    
    def validate_answer(self, question_index: int, answer: str) -> bool:
        if not VALIDATION_CONFIG['AUTO_VALIDATE']:
            return True
        
        question = PERGUNTAS_CONFIG[question_index]
        
        if question['class'] == 'texto':
            if len(answer) < VALIDATION_CONFIG['MIN_TEXT_LENGTH']:
                return False
            if len(answer) > VALIDATION_CONFIG['MAX_TEXT_LENGTH']:
                return False
        
        return True
    
    async def complete_whitelist(self, user: discord.Member):
        try:
            print(f"🔄 Iniciando completar whitelist para {user} (ID: {user.id})")
            
            session = self.bot.db_manager.get_whitelist_session(user.id)
            if not session:
                print(f"❌ Sessão não encontrada para {user}")
                return
            
            print(f"✅ Sessão encontrada para {user}, criando embed...")
            embed = self.bot.embed_builder.create_form_embed(user, session['answers'])
            
            print(f"✅ Embed criado, criando view de moderação...")
            view = ModerationView(user.id, session['answers'], self.bot.moderation_manager)
            
            print(f"🔄 Determinando canal de destino para {user}...")
            channel = self.get_target_channel(user)
            if channel:
                print(f"✅ Canal encontrado: {channel.name} (ID: {channel.id})")
                print(f"🔄 Enviando mensagem no canal...")
                message = await channel.send(embed=embed, view=view)
                print(f"✅ Mensagem enviada com sucesso! ID: {message.id}")
                
                self.bot.db_manager.add_moderation_data(user.id, message.id, session['answers'], channel.id)
                print(f"✅ Dados de moderação salvos")
                
                cooldown_expires = datetime.now() + timedelta(hours=SERVER_CONFIG.get('WHITELIST_COOLDOWN_HOURS', 24))
                cooldown_data = {
                    'user_id': user.id,
                    'message_id': message.id,
                    'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'answers': session['answers'],
                    'cooldown_expires': cooldown_expires.isoformat()
                }
                self.bot.db_manager.add_user_cooldown(user.id, cooldown_data)
                print(f"✅ Cooldown adicionado")

                print(f"🔄 Enviando log de whitelist enviada...")
                await self.send_submitted_log(user, session['answers'])
                print(f"✅ Log enviado")
                
                if SERVER_CONFIG.get('CREATE_THREADS', True):
                    print(f"🔄 Criando thread...")
                    await self.create_message_thread(message, user)
                    print(f"✅ Thread criada")
            else:
                print(f"❌ Canal não encontrado para {user}")
                await user.send("❌ Erro: Canal de destino não encontrado. Entre em contato com a administração.")
                return
            
            print(f"🔄 Removendo sessão de whitelist...")
            self.bot.db_manager.remove_whitelist_session(user.id)
            print(f"✅ Sessão removida")
            
            print(f"🔄 Enviando confirmação para o usuário...")
            await user.send("✅ Sua whitelist foi enviada com sucesso! Aguarde a análise da equipe.")
            print(f"✅ Confirmação enviada")
            
            print(f"🎉 Whitelist completada com sucesso para {user}")
            
        except Exception as e:
            print(f"❌ Erro ao completar whitelist de {user}: {e}")
            import traceback
            traceback.print_exc()

    async def send_submitted_log(self, user: discord.Member, answers: dict):
        try:
            guild = self.bot.get_guild(SERVER_CONFIG['GUILD_ID'])
            if not guild:
                return
            
            logs_channel = guild.get_channel(SERVER_CONFIG.get('LOGS_SUBMITTED_CHANNEL_ID'))
            if not logs_channel:
                return
            
            current_timestamp = int(datetime.now().timestamp())
            
            embed = discord.Embed(
                title="📋 Nova Whitelist Recebida",
                color=0xFFFF00,  # Yellow color
                timestamp=datetime.now()
            )
            
            embed.add_field(name="👤 Usuário:", value=f"{user.mention}", inline=True)
            embed.add_field(name="📛 Username:", value=f"{user.name}", inline=True)
            embed.add_field(name="🆔 ID:", value=f"{user.id}", inline=True)
            
            embed.add_field(name="📅 Enviado em", value=f"<t:{current_timestamp}:F>", inline=False)
            
            # Status
            embed.add_field(name="📊 Status", value="🟡 Aguardando análise", inline=True)
            embed.add_field(name="🕐 Tempo desde o envio", value=f"<t:{current_timestamp}:R>", inline=True)
            
            # Add answers
            answer_count = 0
            for question, answer in answers.items():
                if answer_count >= 5:  # Show up to 5 answers in log
                    break
                
                # Clean question title (remove emojis for cleaner display)
                clean_question = question.replace("🎂", "").replace("🎮", "").replace("👤", "").replace("🎭", "").replace("🧬", "").replace("📖", "").replace("📸", "").strip()
                
                # Truncate long answers
                display_answer = str(answer)[:150] + "..." if len(str(answer)) > 150 else str(answer)
                
                embed.add_field(name=f"❓ {clean_question[:50]}", value=display_answer, inline=False)
                answer_count += 1
            
            if len(answers) > 5:
                embed.add_field(name="➕ Mais respostas", value=f"E mais {len(answers) - 5} respostas no formulário completo", inline=False)
            
            embed.set_thumbnail(url=user.display_avatar.url)
            embed.set_footer(text=f"Sistema de Whitelist • ID: {user.id}")
            
            await logs_channel.send(embed=embed)
            
        except Exception as e:
            print(f"❌ Erro ao enviar log de whitelist enviada: {e}")

    def get_target_channel(self, user: discord.Member):
        try:
            print(f"🔄 Verificando canal de destino para {user} (ID: {user.id})")
            
            guild = self.bot.get_guild(SERVER_CONFIG['GUILD_ID'])
            if not guild:
                print(f"❌ Guild não encontrada: {SERVER_CONFIG['GUILD_ID']}")
                return None
            
            print(f"✅ Guild encontrada: {guild.name}")
            
            member = guild.get_member(user.id)
            if not member:
                print(f"❌ Membro não encontrado no servidor: {user.id}")
                return None
            
            print(f"✅ Membro encontrado no servidor: {member.display_name}")
            
            vip_role_id = SERVER_CONFIG.get('VIP_ROLE_ID')
            print(f"🔄 Verificando cargo VIP (ID: {vip_role_id})")
            
            if vip_role_id and any(role.id == vip_role_id for role in member.roles):
                print(f"✅ Usuário {user} tem cargo VIP, enviando para canal VIP")
                channel = guild.get_channel(SERVER_CONFIG['FORMULARIOS_VIP_CHANNEL_ID'])
                if channel:
                    print(f"✅ Canal VIP encontrado: {channel.name} (ID: {channel.id})")
                else:
                    print(f"❌ Canal VIP não encontrado: {SERVER_CONFIG['FORMULARIOS_VIP_CHANNEL_ID']}")
                return channel
            
            print(f"ℹ️ Usuário {user} não tem cargo VIP, enviando para canal normal")
            channel = guild.get_channel(SERVER_CONFIG['FORMULARIOS_CHANNEL_ID'])
            if channel:
                print(f"✅ Canal normal encontrado: {channel.name} (ID: {channel.id})")
            else:
                print(f"❌ Canal normal não encontrado: {SERVER_CONFIG['FORMULARIOS_CHANNEL_ID']}")
            return channel
            
        except Exception as e:
            print(f"❌ Erro ao verificar canal de destino para {user}: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    async def create_message_thread(self, message: discord.Message, user: discord.Member):
        try:
            thread_name = f"{SERVER_CONFIG.get('THREAD_NAME_PREFIX', 'Whitelist -')} {user.display_name}"
            
            thread = await message.create_thread(
                name=thread_name,
                auto_archive_duration=SERVER_CONFIG.get('THREAD_AUTO_ARCHIVE', 1440)
            )
            
            welcome_msg = f"🧵 Thread criada para discussão da whitelist de {user.mention}"
            await thread.send(welcome_msg)
            
        except Exception as e:
            print(f"❌ Erro ao criar thread para {user}: {e}")
    
    async def cleanup_submitted_form(self, user_id: int):
        try:
            await asyncio.sleep(5)
            self.bot.db_manager.remove_submitted_form(user_id)
            print(f"🧹 Registro de formulário removido para usuário {user_id}")
        except Exception as e:
            print(f"❌ Erro ao limpar formulário enviado: {e}")
    
    async def restore_whitelist_sessions(self):
        try:
            sessions = self.bot.db_manager.get_all_whitelist_sessions()
            
            for user_id, session in sessions.items():
                try:
                    user = self.bot.get_user(int(user_id))
                    if user:
                        embed = discord.Embed(
                            title="🔄 Sessão Restaurada",
                            description="Seu bot foi reiniciado. Clique no botão abaixo para continuar sua whitelist de onde parou.",
                            color=0xffa500
                        )
                        
                        view = ContinueWhitelistView(self, user, session['current_question'])
                        await user.send(embed=embed, view=view)
                        
                except Exception as e:
                    print(f"❌ Erro ao restaurar sessão para usuário {user_id}: {e}")
                    
        except Exception as e:
            print(f"❌ Erro ao restaurar sessões: {e}")

    async def restore_form_buttons(self):
        try:
            print("🔄 Iniciando restauração de botões persistentes...")
            
            cooldowns = self.bot.db_manager.get_all_user_cooldowns()
            
            guild = self.bot.get_guild(SERVER_CONFIG['GUILD_ID'])
            if not guild:
                return
            
            channels = []
            
            try:
                normal_channel = guild.get_channel(SERVER_CONFIG['FORMULARIOS_CHANNEL_ID'])
                if normal_channel:
                    channels.append(normal_channel)
            except Exception:
                pass
            
            try:
                vip_channel = guild.get_channel(SERVER_CONFIG['FORMULARIOS_VIP_CHANNEL_ID'])
                if vip_channel:
                    channels.append(vip_channel)
            except Exception:
                pass
            
            if not channels:
                return
            
            if not cooldowns:
                return
            
            restored_count = 0
            removed_count = 0
            
            for user_id, cooldown_data in cooldowns.items():
                try:
                    if not isinstance(cooldown_data, dict) or 'message_id' not in cooldown_data:
                        continue
                    
                    message_id = cooldown_data['message_id']
                    
                    message_found = False
                    for channel in channels:
                        try:
                            message = await channel.fetch_message(message_id)
                            view = ModerationView(int(user_id), cooldown_data.get('answers', {}), self.bot.moderation_manager)
                            await message.edit(view=view)
                            
                            restored_count += 1
                            message_found = True
                            break
                            
                        except discord.NotFound:
                            continue
                        except Exception:
                            continue
                    
                    if not message_found:
                        self.bot.db_manager.remove_user_cooldown(int(user_id))
                        removed_count += 1
                    
                except Exception:
                    continue
            
            if restored_count > 0:
                print(f"✅ {restored_count} botões persistentes restaurados")
                    
        except Exception as e:
            print(f"❌ Erro ao restaurar botões: {e}")

    async def list_active_whitelists(self, interaction):
        try:
            sessions = self.bot.db_manager.get_all_whitelist_sessions()
            active_list = []
            
            for user_id, session in sessions.items():
                session['user_id'] = int(user_id)
                session['started_at'] = datetime.fromisoformat(session['started_at']).timestamp()
                active_list.append(session)
            
            embed = self.bot.embed_builder.create_whitelist_list_embed(active_list)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            
        except Exception as e:
            await interaction.response.send_message(f"❌ Erro ao listar whitelists: {e}", ephemeral=True)

    async def restore_incomplete_sessions(self):
        try:
            await asyncio.sleep(1)
            
            sessions = self.bot.db_manager.get_all_whitelist_sessions()
            
            for user_id, session in sessions.items():
                try:
                    user = self.bot.get_user(int(user_id))
                    if user and session['status'] == 'active':
                        embed = discord.Embed(
                            title="🔄 Sessão Restaurada",
                            description="O bot foi reiniciado enquanto você estava fazendo sua whitelist. Clique no botão abaixo para continuar de onde parou.",
                            color=0xffa500
                        )
                        
                        view = ContinueWhitelistView(self, user, session['current_question'])
                        await user.send(embed=embed, view=view)
                        
                except Exception as e:
                    print(f"❌ Erro ao restaurar sessão para usuário {user_id}: {e}")
                    
        except Exception as e:
            print(f"❌ Erro ao restaurar sessões incompletas: {e}")

class TextQuestionView(discord.ui.View):
    def __init__(self, handler, user, question_index):
        super().__init__(timeout=None)
        self.handler = handler
        self.user = user
        self.question_index = question_index
        self.answered = False
    
    @discord.ui.button(label='Responder', emoji='✏️', style=discord.ButtonStyle.primary)
    async def answer_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user.id:
            return await interaction.response.send_message("❌ Esta não é sua whitelist!", ephemeral=True)
        
        if self.answered:
            return await interaction.response.send_message("❌ Você já respondeu esta pergunta!", ephemeral=True)
        
        modal = TextAnswerModal(self.handler, self.user, self.question_index, self)
        await interaction.response.send_modal(modal)

class SelectQuestionView(discord.ui.View):
    def __init__(self, handler, user, question_index, question_data):
        super().__init__(timeout=None)
        self.handler = handler
        self.user = user
        self.question_index = question_index
        self.answered = False
        
        options = []
        for i in range(1, 26):
            option_key = f"opcao{i}"
            if option_key in question_data:
                options.append(discord.SelectOption(
                    label=question_data[option_key],
                    value=str(i),
                    description=f"Opção {i}"
                ))
        
        if options:
            select = discord.ui.Select(
                placeholder="Escolha uma opção...",
                options=options,
                custom_id="question_select"
            )
            select.callback = self.select_callback
            self.add_item(select)
    
    async def select_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.user.id:
            return await interaction.response.send_message("❌ Esta não é sua whitelist!", ephemeral=True)
        
        if self.answered:
            return await interaction.response.send_message("❌ Você já respondeu esta pergunta!", ephemeral=True)
        
        selected_option = interaction.data['values'][0]
        question = PERGUNTAS_CONFIG[self.question_index]
        answer = question[f"opcao{selected_option}"]
        
        await interaction.response.send_message(f"✅ Resposta selecionada: **{answer}**", ephemeral=True)
        
        self.answered = True
        
        try:
            disabled_view = discord.ui.View()
            disabled_select = discord.ui.Select(
                placeholder=f"✅ Selecionado: {answer}",
                options=[discord.SelectOption(label="Respondido", value="done")],
                disabled=True
            )
            disabled_view.add_item(disabled_select)
            await interaction.message.edit(view=disabled_view)
        except Exception as e:
            print(f"❌ Erro ao desabilitar select: {e}")
        
        await asyncio.sleep(1)
        
        await self.handler.process_answer(self.user, self.question_index, answer)

class TextAnswerModal(discord.ui.Modal):
    def __init__(self, handler, user, question_index, view=None):
        super().__init__(title="Responder Pergunta")
        self.handler = handler
        self.user = user
        self.question_index = question_index
        self.view = view
        self.original_message = None  # Store reference to message with button
        
        self.answer_input = discord.ui.TextInput(
            label="Sua resposta:",
            placeholder="Digite sua resposta aqui...",
            style=discord.TextStyle.paragraph,
            max_length=VALIDATION_CONFIG['MAX_TEXT_LENGTH'],
            required=True
        )
        self.add_item(self.answer_input)
    
    async def on_submit(self, interaction: discord.Interaction):
        answer = self.answer_input.value
        await interaction.response.send_message(f"✅ Resposta enviada: **{answer[:100]}{'...' if len(answer) > 100 else ''}**", ephemeral=True)
        
        if self.view:
            self.view.answered = True
        
        if self.view:
            try:
                # Find the message with the button that was clicked
                async for message in self.user.history(limit=10):
                    if (message.author.bot and message.embeds and 
                        len(message.components) > 0 and 
                        not message.components[0].children[0].disabled):
                        
                        disabled_view = discord.ui.View()
                        disabled_button = discord.ui.Button(
                            label='✅ Respondido',
                            emoji='✏️',
                            style=discord.ButtonStyle.success,
                            disabled=True
                        )
                        disabled_view.add_item(disabled_button)
                        await message.edit(view=disabled_view)
                        break
            except Exception as e:
                print(f"❌ Erro ao desabilitar botão: {e}")
        
        await asyncio.sleep(1)
        
        success = await self.handler.process_answer(self.user, self.question_index, answer)

class ContinueWhitelistView(discord.ui.View):
    def __init__(self, handler, user, question_index):
        super().__init__(timeout=300)
        self.handler = handler
        self.user = user
        self.question_index = question_index
    
    @discord.ui.button(label='Continuar Whitelist', emoji='▶️', style=discord.ButtonStyle.success)
    async def continue_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user.id:
            return await interaction.response.send_message("❌ Esta não é sua whitelist!", ephemeral=True)
        
        await interaction.response.send_message("✅ Continuando whitelist...", ephemeral=True)
        await self.handler.send_question(self.user, self.question_index)

"""
MIT License
Copyright (c) 2026 Paulo Roberto Duarte Freitas
"""
