import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional

class DatabaseManager:
    def __init__(self):
        self.db_folder = "database"
        self.ensure_database_folder()
        
        self.db_files = {
            'whitelist_sessions': os.path.join(self.db_folder, 'whitelist_sessions.json'),
            'temporary_roles': os.path.join(self.db_folder, 'temporary_roles.json'),
            'moderation_data': os.path.join(self.db_folder, 'moderation_data.json'),
            'user_cooldowns': os.path.join(self.db_folder, 'user_cooldowns.json')
        }
    
    def ensure_database_folder(self):
        if not os.path.exists(self.db_folder):
            os.makedirs(self.db_folder)
    
    def initialize_databases(self):
        for db_name, db_path in self.db_files.items():
            if not os.path.exists(db_path):
                self.save_data(db_name, {})
        
        self.cleanup_databases()
    
    def load_data(self, db_name: str) -> Dict:
        try:
            db_path = self.db_files.get(db_name)
            if not db_path or not os.path.exists(db_path):
                return {}
            
            with open(db_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"❌ Erro ao carregar {db_name}: {e}")
            return {}
    
    def save_data(self, db_name: str, data: Dict):
        try:
            db_path = self.db_files.get(db_name)
            if not db_path:
                return False
            
            with open(db_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            print(f"❌ Erro ao salvar {db_name}: {e}")
            return False
    
    def add_whitelist_session(self, user_id: int, session_data: Dict):
        sessions = self.load_data('whitelist_sessions')
        
        if len(sessions) >= 50:
            sorted_sessions = sorted(sessions.items(), key=lambda x: x[1].get('started_at', ''))
            sessions = dict(sorted_sessions[-49:])  # Keep 49, add 1 = 50 total
        
        sessions[str(user_id)] = {
            **session_data,
            'started_at': datetime.now().isoformat(),
            'last_activity': datetime.now().isoformat()
        }
        self.save_data('whitelist_sessions', sessions)
    
    def get_whitelist_session(self, user_id: int) -> Optional[Dict]:
        sessions = self.load_data('whitelist_sessions')
        return sessions.get(str(user_id))
    
    def update_whitelist_session(self, user_id: int, updates: Dict):
        sessions = self.load_data('whitelist_sessions')
        if str(user_id) in sessions:
            sessions[str(user_id)].update(updates)
            sessions[str(user_id)]['last_activity'] = datetime.now().isoformat()
            self.save_data('whitelist_sessions', sessions)
    
    def remove_whitelist_session(self, user_id: int):
        sessions = self.load_data('whitelist_sessions')
        if str(user_id) in sessions:
            del sessions[str(user_id)]
            self.save_data('whitelist_sessions', sessions)
    
    def get_all_whitelist_sessions(self) -> Dict:
        return self.load_data('whitelist_sessions')
    
    def add_temporary_role(self, user_id: int, role_id: int, expires_at: datetime):
        temp_roles = self.load_data('temporary_roles')
        
        print(f"[v0] DEBUG DB: Salvando cargo temporário com expiração: {expires_at}")
        print(f"[v0] DEBUG DB: Timestamp Unix: {int(expires_at.timestamp())}")
        
        if len(temp_roles) >= 50:
            sorted_roles = sorted(temp_roles.items(), key=lambda x: x[1].get('added_at', ''))
            temp_roles = dict(sorted_roles[-49:])  # Keep 49, add 1 = 50 total
        
        key = f"{user_id}_{role_id}"
        temp_roles[key] = {
            'user_id': user_id,
            'role_id': role_id,
            'expires_at': expires_at.isoformat(),
            'added_at': datetime.now().isoformat()
        }
        self.save_data('temporary_roles', temp_roles)
    
    def get_expired_roles(self) -> List[Dict]:
        temp_roles = self.load_data('temporary_roles')
        expired = []
        now = datetime.now()
        
        for key, role_data in temp_roles.items():
            expires_at = datetime.fromisoformat(role_data['expires_at'])
            if expires_at <= now:
                expired.append(role_data)
        
        return expired
    
    def remove_temporary_role(self, user_id: int, role_id: int):
        temp_roles = self.load_data('temporary_roles')
        key = f"{user_id}_{role_id}"
        if key in temp_roles:
            del temp_roles[key]
            self.save_data('temporary_roles', temp_roles)
    
    def get_user_temporary_roles(self, user_id: int) -> List[Dict]:
        temp_roles = self.load_data('temporary_roles')
        user_roles = []
        
        for role_data in temp_roles.values():
            if role_data['user_id'] == user_id:
                user_roles.append(role_data)
        
        return user_roles
    
    def add_moderation_data(self, user_id: int, message_id: int, form_data: Dict, channel_id: int):
        """Store moderation data for persistent buttons"""
        mod_data = self.load_data('moderation_data')
        
        if len(mod_data) >= 50:
            sorted_data = sorted(mod_data.items(), key=lambda x: x[1]['timestamp'])
            mod_data = dict(sorted_data[-49:])  # Keep 49, add 1 = 50 total
        
        mod_data[str(message_id)] = {
            'user_id': user_id,
            'message_id': message_id,
            'channel_id': channel_id,
            'form_data': form_data,
            'timestamp': datetime.now().isoformat(),
            'status': 'pending'
        }
        
        self.save_data('moderation_data', mod_data)
    
    def get_moderation_data(self, message_id: int) -> Optional[Dict]:
        mod_data = self.load_data('moderation_data')
        return mod_data.get(str(message_id))
    
    def update_moderation_status(self, message_id: int, status: str, moderator_id: int, reason: str = None):
        try:
            print(f"🔄 Atualizando status da mensagem {message_id} para '{status}'")
            
            mod_data = self.load_data('moderation_data')
            if str(message_id) in mod_data:
                old_status = mod_data[str(message_id)].get('status', 'unknown')
                print(f"📝 Status anterior: '{old_status}' -> Novo status: '{status}'")
                
                mod_data[str(message_id)].update({
                    'status': status,
                    'moderator_id': moderator_id,
                    'reason': reason,
                    'processed_at': datetime.now().isoformat()
                })
                
                success = self.save_data('moderation_data', mod_data)
                if success:
                    print(f"✅ Status atualizado com sucesso no moderation_data.json")
                else:
                    print(f"❌ Erro ao salvar dados no moderation_data.json")
            else:
                print(f"❌ Mensagem {message_id} não encontrada no moderation_data.json")
                
        except Exception as e:
            print(f"❌ Erro ao atualizar status da mensagem {message_id}: {e}")
            import traceback
            traceback.print_exc()
    
    def get_all_moderation_data(self) -> Dict:
        return self.load_data('moderation_data')
    
    def remove_moderation_data(self, message_id: int):
        mod_data = self.load_data('moderation_data')
        if str(message_id) in mod_data:
            del mod_data[str(message_id)]
            self.save_data('moderation_data', mod_data)
    
    def add_user_cooldown(self, user_id: int, cooldown_data: Dict):
        """Add user cooldown data for form submissions"""
        cooldowns = self.load_data('user_cooldowns')
        
        if len(cooldowns) >= 50:
            sorted_cooldowns = sorted(cooldowns.items(), key=lambda x: x[1].get('timestamp', ''))
            cooldowns = dict(sorted_cooldowns[-49:])  # Keep 49, add 1 = 50 total
        
        cooldowns[str(user_id)] = cooldown_data
        self.save_data('user_cooldowns', cooldowns)
    
    def get_user_cooldown(self, user_id: int) -> Optional[Dict]:
        """Get user cooldown data"""
        cooldowns = self.load_data('user_cooldowns')
        return cooldowns.get(str(user_id))
    
    def get_user_cooldown_remaining(self, user_id: int) -> Optional[str]:
        """Get remaining cooldown time for user in a formatted string"""
        cooldown_data = self.get_user_cooldown(user_id)
        if not cooldown_data:
            return None
        
        if isinstance(cooldown_data, dict) and 'cooldown_expires' in cooldown_data:
            expires_at = datetime.fromisoformat(cooldown_data['cooldown_expires'])
            now = datetime.now()
            
            if now >= expires_at:
                return None
            
            remaining = expires_at - now
            days = remaining.days
            hours, remainder = divmod(remaining.seconds, 3600)
            minutes, _ = divmod(remainder, 60)
            
            if days > 0:
                return f"{days} dias, {hours} horas e {minutes} minutos"
            elif hours > 0:
                return f"{hours} horas e {minutes} minutos"
            else:
                return f"{minutes} minutos"
        
        return None
    
    def remove_user_cooldown(self, user_id: int):
        """Remove user cooldown data"""
        cooldowns = self.load_data('user_cooldowns')
        if str(user_id) in cooldowns:
            del cooldowns[str(user_id)]
            self.save_data('user_cooldowns', cooldowns)
    
    def get_all_user_cooldowns(self) -> Dict:
        """Get all user cooldown data for persistent buttons"""
        return self.load_data('user_cooldowns')
    
    def get_submitted_form(self, user_id: int) -> Optional[Dict]:
        """Get submitted form data (legacy compatibility - now uses moderation_data)"""
        # Check moderation_data for pending forms from this user
        mod_data = self.load_data('moderation_data')
        for message_id, data in mod_data.items():
            if data.get('user_id') == user_id and data.get('status') == 'pending':
                return {
                    'message_id': data.get('message_id'),
                    'answers': data.get('form_data', {}),
                    'channel_id': data.get('channel_id')
                }
        return None
    
    def is_user_on_cooldown(self, user_id: int) -> bool:
        """Check if user is on cooldown"""
        cooldown_data = self.get_user_cooldown(user_id)
        if not cooldown_data:
            return False
        
        if isinstance(cooldown_data, dict) and 'cooldown_expires' in cooldown_data:
            expires_at = datetime.fromisoformat(cooldown_data['cooldown_expires'])
            return datetime.now() < expires_at
        
        return False
    
    def add_submitted_form(self, user_id: int, message_id: int, answers: Dict):
        """Add submitted form data (legacy compatibility)"""
        # This is now handled by moderation_data, but keeping for compatibility
        pass
    
    def remove_submitted_form(self, user_id: int):
        """Remove submitted form data (legacy compatibility)"""
        # This is now handled by moderation_data, but keeping for compatibility
        pass
    
    def cleanup_databases(self):
        try:
            self.cleanup_expired_sessions()
            self.cleanup_expired_cooldowns()
            print("🧹 Limpeza dos bancos de dados concluída")
        except Exception as e:
            print(f"❌ Erro na limpeza dos bancos de dados: {e}")
    
    def cleanup_expired_sessions(self):
        sessions = self.load_data('whitelist_sessions')
        now = datetime.now()
        expired_sessions = []
        
        for user_id, session in sessions.items():
            last_activity = datetime.fromisoformat(session['last_activity'])
            if (now - last_activity).total_seconds() > 1800:
                expired_sessions.append(user_id)
        
        for user_id in expired_sessions:
            del sessions[user_id]
        
        if expired_sessions:
            self.save_data('whitelist_sessions', sessions)
            print(f"🧹 Removidas {len(expired_sessions)} sessões expiradas")
    
    def cleanup_expired_cooldowns(self):
        cooldowns = self.load_data('user_cooldowns')
        now = datetime.now()
        expired_cooldowns = []
        
        for user_id, cooldown_data in cooldowns.items():
            should_remove = False
            
            if isinstance(cooldown_data, str):
                expires_at = datetime.fromisoformat(cooldown_data)
                if now >= expires_at:
                    should_remove = True
            elif isinstance(cooldown_data, dict):
                if 'cooldown_expires' in cooldown_data:
                    expires_at = datetime.fromisoformat(cooldown_data['cooldown_expires'])
                    if now >= expires_at:
                        del cooldown_data['cooldown_expires']
                        cooldowns[user_id] = cooldown_data
                else:
                    continue
            
            if should_remove:
                expired_cooldowns.append(user_id)
        
        for user_id in expired_cooldowns:
            del cooldowns[user_id]
        
        if expired_cooldowns:
            self.save_data('user_cooldowns', cooldowns)
            print(f"🧹 Removidos {len(expired_cooldowns)} cooldowns expirados")
    
    def remove_all_user_data(self, user_id: int) -> Dict[str, bool]:
        """Remove all user data from all databases (cooldowns, sessions, temp roles, moderation data)
        Returns dict with status of each removal operation"""
        results = {
            'cooldowns': False,
            'sessions': False,
            'temp_roles': False,
            'moderation_data': False
        }
        
        # Remove user cooldowns
        cooldowns = self.load_data('user_cooldowns')
        if str(user_id) in cooldowns:
            del cooldowns[str(user_id)]
            self.save_data('user_cooldowns', cooldowns)
            results['cooldowns'] = True
        
        # Remove whitelist sessions
        sessions = self.load_data('whitelist_sessions')
        if str(user_id) in sessions:
            del sessions[str(user_id)]
            self.save_data('whitelist_sessions', sessions)
            results['sessions'] = True
        
        # Remove temporary roles for this user
        temp_roles = self.load_data('temporary_roles')
        roles_to_remove = []
        for key, role_data in temp_roles.items():
            if role_data.get('user_id') == user_id:
                roles_to_remove.append(key)
        
        if roles_to_remove:
            for key in roles_to_remove:
                del temp_roles[key]
            self.save_data('temporary_roles', temp_roles)
            results['temp_roles'] = True
        
        # Remove moderation data for this user
        mod_data = self.load_data('moderation_data')
        mod_to_remove = []
        for message_id, data in mod_data.items():
            if data.get('user_id') == user_id:
                mod_to_remove.append(message_id)
        
        if mod_to_remove:
            for message_id in mod_to_remove:
                del mod_data[message_id]
            self.save_data('moderation_data', mod_data)
            results['moderation_data'] = True
        
        return results

"""
MIT License
Copyright (c) 2026 Paulo Roberto Duarte Freitas
"""
