# ================================
# CONFIGURAÇÕES DAS PERGUNTAS
# ================================
# Configure aqui todas as perguntas que serão feitas na whitelist
# Máximo: 10 perguntas

PERGUNTAS_CONFIG = [
    # Pergunta 1 - Texto
    {
        "class": "texto",
        "title": "📝 Qual é o seu nome completo?",
        "description": "Por favor, informe seu nome completo para identificação."
    },
    
    # Pergunta 2 - Texto
    {
        "class": "texto", 
        "title": "🎂 Quantos anos você tem na vida real?",
        "description": "Por favor, informe sua idade real."
    },
    
    # Pergunta 3 - Texto
    {
        "class": "texto",
        "title": "🎮 Qual seu nickname no minecraft?",
        "description": "Informe seu nome de usuário no Minecraft."
    },
    
    # Pergunta 4 - Texto
    {
        "class": "texto",
        "title": "👤 Como será o nome do seu personagem?",
        "description": "Escolha um nome para seu personagem no roleplay."
    },
    
    # Pergunta 5 - Texto
    {
        "class": "texto",
        "title": "🎭 Qual será a idade do seu personagem?",
        "description": "Defina a idade do seu personagem no roleplay."
    },
    
    # Pergunta 6 - Select
    {
        "class": "select",
        "title": "🧬 Qual será a raça do personagem?",
        "description": "Selecione a raça do seu personagem.",
        "opcao1": "Anão",
        "opcao2": "Orc", 
        "opcao3": "Goblin",
        "opcao4": "Fada",
        "opcao5": "Golem",
        "opcao6": "Feral",
        "opcao7": "Humano",
        "opcao8": "Amanita",
        "opcao9": "Serpentai",
        "opcao10": "Mermaid",
        "opcao11": "Draconato",
        "opcao12": "Tiefling",
        "opcao13": "Elfo",
        "opcao14": "Carapaça"
    },
    
    # Pergunta 7 - Arquivo
    {
        "class": "arquivo",
        "title": "📖 Envie um arquivo com a história do seu personagem",
        "description": "Arquivo PDF, DOC, DOCX com a história completa do seu personagem."
    },
    
    # Pergunta 8 - Arquivo
    {
        "class": "arquivo",
        "title": "📸 Fotos do seu modelo e skin 64",
        "description": "Envie até 5 arquivos com fotos do seu modelo e skin."
    }
]

# ================================
# CONFIGURAÇÕES DE VALIDAÇÃO
# ================================
# Configure as regras de validação para as respostas

VALIDATION_CONFIG = {
    # Tamanho mínimo de resposta para perguntas de texto
    'MIN_TEXT_LENGTH': 0,  # Sem mínimo de caracteres
    
    # Tamanho máximo de resposta para perguntas de texto  
    'MAX_TEXT_LENGTH': 1000,
    
    # Tipos de arquivo aceitos para perguntas de arquivo
    'ACCEPTED_FILE_TYPES': ['.png', '.jpg', '.jpeg', '.gif', '.pdf', '.txt', '.doc', '.docx'],
    
    # Tamanho máximo de arquivo (em MB)
    'MAX_FILE_SIZE_MB': 10,
    
    # Se deve validar respostas automaticamente
    'AUTO_VALIDATE': True,
    
    # Mensagens de validação
    'VALIDATION_MESSAGES': {
        'TEXT_TOO_LONG': '❌ Resposta muito longa! Máximo de {max} caracteres.',
        'FILE_TOO_LARGE': '❌ Arquivo muito grande! Máximo de {max}MB.',
        'FILE_TYPE_INVALID': '❌ Tipo de arquivo não aceito! Tipos aceitos: {types}',
        'RESPONSE_INVALID': '❌ Resposta inválida! Tente novamente.'
    }
}

# ================================
# CONFIGURAÇÕES DE TEMPO LIMITE
# ================================
# Configure os tempos limite para cada tipo de pergunta

TIMEOUT_CONFIG = {
    # Tempo limite para responder pergunta de texto (em segundos)
    'TEXT_TIMEOUT': 300,  # 5 minutos
    
    # Tempo limite para responder pergunta de seleção (em segundos)
    'SELECT_TIMEOUT': 180,  # 3 minutos
    
    # Tempo limite para enviar arquivo (em segundos)
    'FILE_TIMEOUT': 600,  # 10 minutos
    
    # Número máximo de tentativas por pergunta
    'MAX_ATTEMPTS': 3,
    
    # Se deve avisar sobre tempo limite
    'WARN_TIMEOUT': True,
    
    # Tempo para avisar antes do timeout (em segundos)
    'WARN_BEFORE_TIMEOUT': 60,  # 1 minuto antes
}

"""
MIT License
Copyright (c) 2026 Paulo Roberto Duarte Freitas
"""
