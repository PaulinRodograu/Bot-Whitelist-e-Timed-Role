# ================================
# CONFIGURAÇÕES BÁSICAS DO SERVIDOR
# ================================

# ID do servidor Discord onde o bot vai funcionar
GUILD_ID = 1340190434047168605  # Substitua pelo ID real do seu servidor

# ID do canal onde o painel de whitelist será enviado
PAINEL_CHANNEL_ID = 1412200293977817231  # Substitua pelo ID real do canal do painel

# ================================
# CONFIGURAÇÕES DE CANAIS
# ================================

# Canal onde formulários normais serão enviados (usuários sem cargo VIP)
FORMULARIOS_CHANNEL_ID = 1413115396218683473  # Usando o ID do canal normal do erro

# Canal onde formulários VIP serão enviados (usuários com cargo VIP)
FORMULARIOS_VIP_CHANNEL_ID = 1420173363888001175  # Usando o ID do canal VIP do erro

# Canal onde serão registrados logs de whitelists APROVADAS
LOGS_APPROVED_CHANNEL_ID = 1412200347425964112  # Substitua pelo ID real do canal de logs aprovados

# Canal onde serão registrados logs de whitelists NEGADAS
LOGS_DENIED_CHANNEL_ID = 1420149333256306688  # Substitua pelo ID real do canal de logs negados

# Canal onde serão registrados logs de whitelists ENVIADAS
LOGS_SUBMITTED_CHANNEL_ID = 1420156365543837776  # Substitua pelo ID real do canal de logs enviados

# Canal geral de logs (para outros tipos de logs como cargos temporários)
LOGS_CHANNEL_ID = 1420174004525727766  # Substitua pelo ID real do canal de logs gerais

# ================================
# CONFIGURAÇÕES DE CATEGORIAS
# ================================

# Categoria onde ficam os canais de whitelist (opcional)
WHITELIST_CATEGORY_ID = None  # Deixe None se não quiser usar categoria específica

# ================================
# CONFIGURAÇÕES DE CARGOS
# ================================

# Cargo que será dado ao usuário APENAS quando um moderador APROVAR o formulário
APPROVED_ROLE_ID = 1413957972199211179, 1413993797628727436 # Substitua pelos IDs reais dos cargos aprovados

# Cargo VIP que direciona formulários para canal especial
VIP_ROLE_ID = 1419497026877526168  # Substitua pelo ID real do cargo VIP

# ================================
# CONFIGURAÇÕES DE COMANDOS E PERMISSÕES
# ================================

# IDs dos cargos que podem usar cada comando (moderadores)
COMMAND_PERMISSIONS = {
    "wl": [
        1420236413517037699,
        1413224795335692422, # Substitua pelo ID real do cargo moderador
    ],
    "painel": [
        1420236413517037699,
        1413224795335692422, # Substitua pelo ID real do cargo moderador
    ],
    "role-add": [
        1420236413517037699,
        1413224795335692422, # Substitua pelo ID real do cargo moderador
    ],
    "role-remove": [
        1420236413517037699,
        1413224795335692422, # Substitua pelo ID real do cargo moderador
    ],
    "role-list": [
        1420236413517037699,
        1413224795335692422, # Substitua pelo ID real do cargo moderador
    ],
    "role-temp": [
        1420236413517037699,
        1413224795335692422, # Substitua pelo ID real do cargo moderador
    ],
    "reset-cooldown": [
        1420236413517037699,
        1413224795335692422, # Substitua pelo ID real do cargo moderador
    ],
}

# ================================
# CONFIGURAÇÕES DE FUNCIONALIDADES (TRUE/FALSE)
# ================================

# Configurações de threads
CREATE_THREADS = True  # Criar threads para cada formulário
THREAD_AUTO_ARCHIVE = 1440  # Tempo em minutos para arquivar thread automaticamente

# Configurações de notificações
NOTIFY_NEW_WHITELIST = True  # Notificar quando novo formulário chegar
NOTIFY_WHITELIST_START = False  # Notificar quando usuário começar a preencher
NOTIFY_WHITELIST_TIMEOUT = True  # Notificar quando formulário expirar

# Configurações de comandos
DELETE_COMMAND_MESSAGES = True  # Deletar mensagens de comando após uso
DELETE_COMMAND_DELAY = 5  # Tempo em segundos para deletar mensagem

# ================================
# CONFIGURAÇÕES DE LIMITES E COOLDOWNS
# ================================

# Máximo de whitelists por usuário
MAX_WHITELISTS_PER_USER = 1

# Tempo de cooldown entre whitelists (em horas)
WHITELIST_COOLDOWN_HOURS = 2

# ================================
# CONFIGURAÇÕES DE NOTIFICAÇÕES AVANÇADAS
# ================================

# ID do cargo que será mencionado em notificações
MENTION_ROLE_ID = 1388343191744413826

# Prefixo para nome das threads criadas
THREAD_NAME_PREFIX = 'Whitelist -'

# ================================
# CONFIGURAÇÃO FINAL DO SERVIDOR
# ================================

SERVER_CONFIG = {
    'GUILD_ID': GUILD_ID,
    'PAINEL_CHANNEL_ID': PAINEL_CHANNEL_ID,
    'FORMULARIOS_CHANNEL_ID': FORMULARIOS_CHANNEL_ID,
    'FORMULARIOS_VIP_CHANNEL_ID': FORMULARIOS_VIP_CHANNEL_ID,
    'LOGS_APPROVED_CHANNEL_ID': LOGS_APPROVED_CHANNEL_ID,
    'LOGS_DENIED_CHANNEL_ID': LOGS_DENIED_CHANNEL_ID,
    'LOGS_SUBMITTED_CHANNEL_ID': LOGS_SUBMITTED_CHANNEL_ID,
    'LOGS_CHANNEL_ID': LOGS_CHANNEL_ID,
    'WHITELIST_CATEGORY_ID': WHITELIST_CATEGORY_ID,
    'APPROVED_ROLE_ID': APPROVED_ROLE_ID,  # Renomeado de AUTO_ROLE_ID para APPROVED_ROLE_ID
    'VIP_ROLE_ID': VIP_ROLE_ID,
    'CREATE_THREADS': CREATE_THREADS,
    'THREAD_NAME_PREFIX': THREAD_NAME_PREFIX,
    'THREAD_AUTO_ARCHIVE': THREAD_AUTO_ARCHIVE,
    'MAX_WHITELISTS_PER_USER': MAX_WHITELISTS_PER_USER,
    'WHITELIST_COOLDOWN_HOURS': WHITELIST_COOLDOWN_HOURS,
    'DELETE_COMMAND_MESSAGES': DELETE_COMMAND_MESSAGES,
    'DELETE_COMMAND_DELAY': DELETE_COMMAND_DELAY,
    'NOTIFY_NEW_WHITELIST': NOTIFY_NEW_WHITELIST,
    'MENTION_ROLE_ID': MENTION_ROLE_ID,
    'NOTIFY_WHITELIST_START': NOTIFY_WHITELIST_START,
    'NOTIFY_WHITELIST_TIMEOUT': NOTIFY_WHITELIST_TIMEOUT,
}

"""
MIT License
Copyright (c) 2026 Paulo Roberto Duarte Freitas
"""
