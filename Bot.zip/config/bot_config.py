# ================================
# CONFIGURAÇÕES DO BOT
# ================================
# Aqui você pode configurar todas as informações básicas do seu bot

BOT_CONFIG = {
    # Token do bot (obtenha em https://discord.com/developers/applications)
    'TOKEN': 'MTQyMDM5NDIyMTM5NDg1NDAyNw.GIk8FN.ZVtn9UdvVmJjhSyMSSouKtr7tOEmz2IoeGI-Eg',
    
    # Prefixo dos comandos
    'PREFIX': 'cc.',
    
    # Status personalizado do bot
    'STATUS_TYPE': 'watching',  # Opções: 'playing', 'watching', 'listening'
    'STATUS_TEXT': 'as whitelists do servidor',
    
    # Configurações de embed padrão
    'DEFAULT_EMBED_COLOR': 0x2b2d31,  # Cor padrão dos embeds (formato hexadecimal)
    
    # Configurações de tempo
    'WHITELIST_TIMEOUT': 1800,  # Tempo limite para completar whitelist (30 minutos)
    'DATABASE_CLEANUP_HOURS': 24,  # Intervalo de limpeza automática dos bancos de dados
    
    # Configurações de sincronização de comandos
    'FORCE_SYNC': False,  # Força sincronização de comandos mesmo se já existirem (use apenas em desenvolvimento)
}

# ================================
# CONFIGURAÇÕES DE EMBEDS
# ================================
# Configure aqui os embeds que serão usados pelo bot

EMBED_CONFIGS = {
    # Embed do painel principal
    'PAINEL_PRINCIPAL': {
        'title': f'**Clique no botão abaixo para iniciar sua solicitação de whitelist!**',
        'description': f'-# *Importante: Certifique-se de ter suas DMs abertas para receber as perguntas.*',
        'color': 0x0485e6,
        'image': 'https://media.discordapp.net/attachments/1420399703144796242/1420401004435865610/banner2343.png?ex=68d54305&is=68d3f185&hm=2a9b7b5ef4cb6174a6f4076b857552f03cc320ebb492c3517d23fe1389cac2c8&=&format=webp&quality=lossless&width=1214&height=227',  # URL da imagem (opcional)
        'thumbnail': 'https://media.discordapp.net/attachments/1420399703144796242/1420401004901437511/image3454.png?ex=68d54305&is=68d3f185&hm=5d063d48c39840cb40d3dde2b014588b19cc7d45f14dfa1c66ba3622c3dd286b&=&format=webp&quality=lossless',  # URL da thumbnail (opcional)
        'footer': 'Whitelist',
        'footer_icon': 'https://media.discordapp.net/attachments/1420399703144796242/1420401004901437511/image3454.png?ex=68d54305&is=68d3f185&hm=5d063d48c39840cb40d3dde2b014588b19cc7d45f14dfa1c66ba3622c3dd286b&=&format=webp&quality=lossless'  # URL do ícone do footer (opcional)
    },
    
    # Embed de confirmação de DM
    'CONFIRMACAO_DM': {
        'title': '✉️ Abrir DMs',
        'description': 'Para continuar com sua whitelist, você precisa abrir suas mensagens diretas neste servidor.\n\n**Como fazer:**\n1. Clique com o botão direito no servidor\n2. Vá em "Configurações de Privacidade"\n3. Ative "Permitir mensagens diretas de membros do servidor"\n\nApós fazer isso, clique no botão abaixo para continuar!',
        'color': 0xffa500,
        'image': '',
        'thumbnail': '',
        'footer': 'Sistema de Whitelist',
        'footer_icon': ''
    },
    
    # Embed de formulário enviado
    'FORMULARIO_ENVIADO': {
        'title': '📝 Nova Whitelist Recebida',
        'description': 'Um novo formulário de whitelist foi enviado.',
        'color': 0x00ff00,
        'image': '',
        'thumbnail': '',
        'footer': 'Sistema de Whitelist',
        'footer_icon': ''
    },
    
    # Embed de ajuda
    'HELP': {
        'title': '❓ Comandos Disponíveis',
        'description': 'Lista de todos os comandos do bot e como usá-los.',
        'color': 0x0099ff,
        'image': '',
        'thumbnail': '',
        'footer': 'Sistema de Ajuda',
        'footer_icon': ''
    }
}

# ================================
# MENSAGENS DO BOT
# ================================
# Configure aqui as mensagens que o bot enviará

MESSAGES = {
    # Mensagens de erro
    'ERRO_DM_FECHADA': '❌ Não consegui enviar mensagem na sua DM. Certifique-se de que suas mensagens diretas estão abertas!',
    'ERRO_WHITELIST_ATIVA': '⚠️ Você já tem uma whitelist em andamento! Complete-a antes de iniciar uma nova.',
    'ERRO_WHITELIST_ENVIADA': '⚠️ Você já enviou uma whitelist recentemente. Aguarde a análise!',
    'ERRO_TIMEOUT': '⏰ Tempo esgotado! Sua whitelist foi cancelada por inatividade.',
    'ERRO_ARQUIVO_INVALIDO': '❌ Arquivo inválido! Envie apenas imagens ou documentos.',
    
    # Mensagens de sucesso
    'WHITELIST_INICIADA': '✅ Whitelist iniciada! Verifique sua DM para responder às perguntas.',
    'WHITELIST_ENVIADA': '✅ Sua whitelist foi enviada com sucesso! Aguarde a análise da equipe.',
    'CARGO_ADICIONADO': '✅ Cargo adicionado com sucesso!',
    'CARGO_REMOVIDO': '✅ Cargo removido com sucesso!',
    
    # Mensagens informativas
    'AGUARDANDO_RESPOSTA': '⏳ Aguardando sua resposta...',
    'PROXIMA_PERGUNTA': '➡️ Próxima pergunta:',
    'WHITELIST_CANCELADA': '❌ Whitelist cancelada.',
}

"""
MIT License
Copyright (c) 2026 Paulo Roberto Duarte Freitas
"""
